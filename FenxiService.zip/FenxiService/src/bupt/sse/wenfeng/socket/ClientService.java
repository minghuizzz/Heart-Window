package bupt.sse.wenfeng.socket;
import java.io.*;
import java.net.*;
import java.util.List;
import bupt.sse.wenfeng.fenxisuanfa.Fenxi;
import bupt.sse.wenfeng.login.Login;
import bupt.sse.wenfeng.luru.NewStudent;
import bupt.sse.wenfeng.register.Register;
import bupt.sse.wenfeng.startFX.AllFx;
import bupt.sse.wenfeng.startFX.StartFX;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
public class ClientService extends Thread{
	public Socket socket;
public ClientService(Socket socket){
	this.socket = socket;
}
public  void run(){
	try {
		BufferedReader is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
		
		String meg = is.readLine();
		JSONObject meg_json = JSONObject.fromObject(meg);
	//	System.out.println(meg_json);
		int cmd =  (Integer) meg_json.get("cmd");
		if(cmd==1){
			String name = (String) meg_json.get("username");
			String password = (String) meg_json.get("password");
			String uid = (String) meg_json.get("uid");
			Register r = new Register(name,password,uid,socket);
			r.start();
		}
		if(cmd==2){
			String name = (String) meg_json.get("username");
			String password = (String) meg_json.get("password");			
			Login log = new Login(name,password,socket);
			log.start();
		}
		else if(cmd==3){
		String uid = (String) meg_json.get("uid");
		StartFX sFX = new StartFX(uid,socket);
		sFX.start();
		
		}
		else if(cmd==4){
			String name = (String) meg_json.get("username");
			AllFx af= new AllFx(name,socket);
			af.start();
		}
		else if(cmd==5){
			String name = (String) meg_json.get("name");
			String student = (String) meg_json.get("student");
			String uid = (String) meg_json.get("uid");
			NewStudent ns = new NewStudent(name,student,uid,socket);
			ns.start();
		}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
