package bupt.sse.wenfeng.socket;
import java.io.*;
import java.net.*;
import java.util.List;
import java.applet.Applet;

import bupt.sse.wenfeng.fenxisuanfa.Fenxi;
import bupt.sse.wenfeng.startFX.StartFX;



public class Service {
	private static ServerSocket server =null;
		public  void openService(){
			try{
				server = new ServerSocket(4040);
				System.out.println("Server start!!");
				while(true){
					Socket socket = server.accept();
					System.out.println("some one come...");
					ClientService cs = new ClientService(socket);
					cs.start();
				}
			}
			catch(Exception e) {
				System.out.println("Error."+e);
				}
		}
		

		
		public static void main(String[] args){
			Service s = new Service();
			s.openService();
		}
}
