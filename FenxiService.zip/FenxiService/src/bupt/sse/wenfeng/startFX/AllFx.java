package bupt.sse.wenfeng.startFX;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import bupt.sse.wenfeng.fenxisuanfa.Ends;
import bupt.sse.wenfeng.fenxisuanfa.Fenxi;
import bupt.sse.wenfeng.option.Option;
import bupt.sse.wenfeng.unicode.UnicodeReader;

public class AllFx extends Thread{
	public String username = null;
	public Socket socket = null;
	private BufferedReader br =null;
	private List<Float> all = null;
	private PrintWriter os =null;
	public AllFx(String username,Socket socket){
		this.username = username;
		this.socket = socket;
		all = new ArrayList<Float>();
	}
	public void run(){
		try {
			os = new PrintWriter(socket.getOutputStream());
			FileInputStream fis = new FileInputStream("./users/"+username+".txt");  
			UnicodeReader ur = new UnicodeReader(fis, Charset.defaultCharset().name());  
			br = new BufferedReader(ur); 
			/*br = new BufferedReader(new InputStreamReader
					 (new FileInputStream("./users/"+username+".txt")//"C:\\Users\\Feng\\Desktop\\documents\\"+
					 ));
			*/
			JSONArray careArray = new JSONArray();
			JSONArray students = new JSONArray();
			int num_of_fu = 0;
			int num_of_zheng = 0;
			int num_of_0 = 0;
			int num_of_all = 0;
			for (String line = br.readLine(); line != null; line = br.readLine()) {
				Float min = 0.0f;
				String centext = null;
				String uid = br.readLine();
				StartFX sf = new StartFX(uid);
				JSONObject stu = new JSONObject();				
				stu.put("name", line);
				stu.put("uid", uid);
				students.add(stu);
				sf.getDatasByCssQueryUserBaidu(uid, "Baiduspider");
				Fenxi fx = new Fenxi();
				Ends e = fx.getList(uid);
				List<Float> l = e.fList;
				System.out.println(l.size());
				for(int i=0;i<l.size();i++){
					if(i<all.size()){
						Float newF = (all.get(i)+l.get(i))/2;
						newF=(float)(Math.round(newF*10)/10);
						all.set(i, newF);
					}
					else{
						Float newF = l.get(i);
						newF=(float)(Math.round(newF*10)/10);
						all.add(newF);
					}
					if(l.get(i)==0f){
						num_of_0++;
					}
					else if(l.get(i)<0f){
						num_of_fu++;
					}
					else if(l.get(i)>0f){
						num_of_zheng++;
					}
					num_of_all++;
				}
				if(e.min<-1.0f || e.min==-1.0f){
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("name", line);
					//jsonObject.put("min", e.min);
					jsonObject.put("context", e.minString);
					jsonObject.put("uid", uid);
					careArray.add(jsonObject);
				}
			}
			JSONObject jsonObject = new JSONObject();
			JSONArray jsonArray = new JSONArray();
			for(int i=0;i<all.size();i++){
				jsonArray.add(i, all.get(i));
				
			}
			Option op = new Option(jsonArray);
			jsonObject.put("cmd", "41");
			jsonObject.put("lineOption", op.getLine());
			jsonObject.put("sanOption", op.getSan(num_of_zheng, num_of_0, num_of_fu));
			jsonObject.put("care", careArray);
			jsonObject.put("students", students);
			
			//System.out.println(jsonObject.get("cmd"));
			//System.out.println(jsonObject.toString()+all.size());
			os.println(jsonObject.toString());
			os.flush();
			all.clear();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
