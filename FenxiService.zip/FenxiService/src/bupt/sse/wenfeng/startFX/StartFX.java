package bupt.sse.wenfeng.startFX;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;  
import java.util.Random;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import bupt.sse.wenfeng.core.ExtractService;  
import bupt.sse.wenfeng.fenxisuanfa.Ends;
import bupt.sse.wenfeng.fenxisuanfa.Fenxi;
import bupt.sse.wenfeng.option.Option;
import bupt.sse.wenfeng.rule.Rule;  
  
public class StartFX  extends Thread
{   
	public String uid = null;
	public Socket socket =null;
	public StartFX(String uid,Socket socket){
		this.uid = uid ;
		this.socket = socket;
	}
	public StartFX(String uid){
		this.uid = uid ;
	}
    public void getDatasByCssQueryUserBaidu(String uid,String agent)  
    {  
        Rule rule = new Rule(uid,"WB_text", Rule.CLASS, Rule.GET,agent);
        ExtractService.extract(rule);  
    }  
    public void run(){
    	PrintWriter os;
		try {
		os = new PrintWriter(socket.getOutputStream());		
    	getDatasByCssQueryUserBaidu(uid,"Baiduspider");
		Fenxi fx = new Fenxi();
		Ends e = fx.getList(uid);
		List<Float> l = e.fList;
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		
		int num_of_0 = 0;
		int num_of_fu = 0;
		int num_of_zheng = 0;
		int num_of_all = 0;
		for(int i=0;i<l.size();i++){
			jsonArray.add(i, l.get(i));
			if(l.get(i)==0f){
				num_of_0++;
			}
			else if(l.get(i)<0f){
				num_of_fu++;
			}
			else if(l.get(i)>0f){
				num_of_zheng++;
			}
			num_of_all++;
		}
		Option op = new Option(jsonArray);
		jsonObject.put("uid", uid);
		jsonObject.put("lineOption", op.getLine());
		jsonObject.put("sanOption", op.getLine3(null, null, null, num_of_zheng, num_of_0,num_of_fu,num_of_all));
		System.out.println(jsonObject.toString());
		os.println(jsonObject.toString());
		os.flush();
		l.clear();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}  
