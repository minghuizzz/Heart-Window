package bupt.sse.wenfeng.fenxisuanfa;
import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.FileReader;  
import java.io.IOException;  
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.List;
import java.util.StringTokenizer;
import java.util.ArrayList;

import bupt.sse.wenfeng.unicode.UnicodeReader;

import com.sun.jna.Library;
import com.sun.jna.Native;

public class Fenxi {

	public static String dll="./lib/win64/NLPIR";//C://Users//Feng//workspace//fenci
	public static String data ="";//C:/Users/Feng/workspace/fenci/
	public static String[] saveEnd= new String[]{"/xm","/n","/v","/d","/vn","/w"};
	public static String[] saveW = new String[]{"wj","ww","wt","wd","wf"};
	public static List<String> biaoqingList = new ArrayList<String>();
	public static List<String> chengdu = new ArrayList<String>();
	
	public static List<String> chaochengdu = new ArrayList<String>();
    public static List<String> zhengmianqingxu = new ArrayList<String>();
    public static List<String> fumianqingxu = new ArrayList<String>();
    public static List<Float> biaoqingzhisu = new ArrayList<Float>();
	public static List<Float> fumianzhisu = new ArrayList<Float>();
	public static List<Float> zhengmianzhisu = new ArrayList<Float>();
	public static List<Float> chengduzhisu = new ArrayList<Float>();
    public  List<Float> saveSocer = new ArrayList<Float>();

	public interface CLibrary extends Library {
		CLibrary Instance = (CLibrary) Native.loadLibrary(
				dll, CLibrary.class);
		public int NLPIR_Init(byte[] sDataPath, int encoding,
				byte[] sLicenceCode);

		public String NLPIR_ParagraphProcess(String sSrc, int bPOSTagged);

		public String NLPIR_GetKeyWords(String sLine, int nMaxKeyLimit,
				boolean bWeightOut);
		public void NLPIR_AddUserWord(String add);
		
		public void NLPIR_Exit();
	}

	public static String transString(String aidString, String ori_encoding,
			String new_encoding) {
		try {
			return new String(aidString.getBytes(ori_encoding), new_encoding);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public  Ends getList(String uid) {
		biaoqing();
		zmQX();
		cdZS();
		fmQX();
		String minString=null;
		Float min=0f;
		String argu = data;
		 String system_charset = "GBK";//GBK----0
		 int charset_type = 1;
                 try{
		int init_flag = CLibrary.Instance.NLPIR_Init(argu
				.getBytes(system_charset), charset_type, "0"
				.getBytes(system_charset));

                 
		if (0 == init_flag) {
			System.err.println("");
			//return null;
		}
                }catch(UnsupportedEncodingException e){
                 }
		String nativeBytes = null;
		try {
			 FileInputStream fis = new FileInputStream("./students/"+uid+".txt");  
			 UnicodeReader ur = new UnicodeReader(fis, Charset.defaultCharset().name());  
			 BufferedReader	br = new BufferedReader(ur); 
			 		
				        for (String line = br.readLine(); line != null; line = br.readLine()) {
				        	if(!line.equals("") && !line.startsWith("转发:")){
				        	System.out.println(line);
				        	Float saveS = 0f;
				        	
				        	int count =1;
				        	nativeBytes = CLibrary.Instance.NLPIR_ParagraphProcess(line, 1);               
				        	//System.out.println(nativeBytes);
				        	StringTokenizer st = new StringTokenizer(nativeBytes);
				        	List<String> words = new ArrayList<String>();
				            while (st.hasMoreTokens()) {
				            	String s = st.nextToken();
				            	if(!isEnd(s)){
				               for(String e : saveEnd){//
				            	   if(s.endsWith(e)){
				            		   StringTokenizer st2 = new StringTokenizer(s,"/");
				            		   if(st2.hasMoreTokens()){
				            		   words.add(st2.nextToken());
				            		   }
				            		   break;
				            	   }
				               }
				               }
				            	else{
				            		Float ends = qingganfenxi(words);
				            		if(ends!=0f){
				            			count++;
				            			saveS+=ends;
				            		}				            						            		
				            		words.clear();
				            	}
				               
				            }
				            saveS+=qingganfenxi(words);
				            count++;
				            //System.out.println(count);
				            Float avg = saveS/count;
                            saveSocer.add(avg);
                            if(avg<min){
                            	min = avg;
                            	minString = line;
                            }
                            //System.out.println(min);
				            System.err.println(avg);
				        	}
				        }
				        
				        br.close();

			CLibrary.Instance.NLPIR_Exit();
                        
		} 
                catch (Exception ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
                //return saveSocer;
                return new Ends(saveSocer,minString,min);
        }
	public static Float qingganfenxi(List<String> words){
		String e=null;
		Float BQsoc = 0f;
		Float CDsoc = 0f;
		Float QXsoc = 0f;
		float count =0f;
		boolean qx = false;
		for(int j=0;j<words.size();j++){
			
			e=words.get(j);
			String bq=null;
			for(int i=0;i<biaoqingList.size();i++){
				bq=biaoqingList.get(i);
				if(e.equals(bq)){
				count++;
				BQsoc+=biaoqingzhisu.get(i);
				BQsoc = BQsoc/2;
				words.remove(j);
				break;
				}
			}			
		}
		for(int j=0;j<words.size();j++){
			e=words.get(j);
			String bq=null;
			for(int i=0;i<zhengmianqingxu.size();i++){
				
				bq=zhengmianqingxu.get(i);
				if(e.equals(bq)){
				QXsoc+=zhengmianzhisu.get(i);
				//System.out.println(e+bq+"  "+words);
				qx = true;
				words.remove(j);
				break;
				}
			}
		}
		for(int j=0;j<words.size();j++){
			e=words.get(j);
			String bq=null;
			
			for(int i=0;i<fumianqingxu.size();i++){
				bq=fumianqingxu.get(i);
				if(e.equals(bq)){
				QXsoc+=fumianzhisu.get(i);
				//System.err.println(e+bq+"  "+words);
				qx = true;
				words.remove(j);
				break;
				}
			}
		}
		for(int j=0;j<words.size();j++){
			e=words.get(j);
			String bq=null;
			for(int i=0;i<chengdu.size();i++){
				bq=chengdu.get(i);
				if(e.equals(bq)){
				CDsoc+=chengduzhisu.get(i);
				words.remove(j);
				break;
				}
			}
		}
		if(BQsoc!=0f || CDsoc!=0f ||QXsoc!=0f){
			count=1f;
		}
		if(BQsoc!=0f){
			count=count*BQsoc;
		}
		if(CDsoc!=0f &&(BQsoc!=0f ||QXsoc!=0f )){
			count=count*CDsoc;
		}
		if(QXsoc!=0f){
			count=count*QXsoc;
		}
		//if(qx)
		//System.out.println("qx :"+QXsoc+"  "+BQsoc+"  "+CDsoc+"  ");
		return count;
	}
	
	public static void biaoqing(){
		BufferedReader br=null;
		try {
			 br = new BufferedReader(new InputStreamReader
					 (new FileInputStream("./cidian/weibobiaoqing.txt")
					 ));
			 			int i =0;
				        for (String line = br.readLine(); line != null; line = br.readLine()) {
				        	if(i%2==0){
				        		biaoqingList.add(line);
				        	}
				        	else{
				        		biaoqingzhisu.add(Float.valueOf(line));
				        	}
				        	i++;
				        }
				        br.close();
		}catch(Exception ex){
			
			System.out.println(ex);
		}
	}
	public static void zmQX(){
		BufferedReader br=null;
		try {
			 br = new BufferedReader(new InputStreamReader
					 (new FileInputStream("./cidian/zhengmianqinggan.txt")
					 ));
			 			int i =0;
				        for (String line = br.readLine(); line != null; line = br.readLine()) {
				        	StringTokenizer st = new StringTokenizer(line);
				        	if(st.hasMoreTokens()){
				        		line=st.nextToken();
				        	}
				        	if(i%2==0){
				        		zhengmianqingxu.add(line);
				        		//System.out.println("add biaoq");
				        	}
				        	else{
				        		zhengmianzhisu.add(Float.valueOf(line));
				        		//System.out.println("add biaoqzhisu");
				        	}
				        	i++;
				        //	zhengmianqingxu.add(line);
				        }
				        br.close();
		}catch(Exception ex){
			
			System.out.println(ex);
		}
	}

	public static void fmQX(){
		BufferedReader br=null;
		try {
			 br = new BufferedReader(new InputStreamReader
					 (new FileInputStream("./cidian/fumianqinggan.txt")
					 ));
			 			int i =0;
				        for (String line = br.readLine(); line != null; line = br.readLine()) {
				        	StringTokenizer st = new StringTokenizer(line);
				        	if(st.hasMoreTokens()){
				        		line = st.nextToken();
				        	}
				        	if(i%2==0){
				        		fumianqingxu.add(line);
				        		//System.out.println("add biaoq");
				        	}
				        	else{
				        		fumianzhisu.add(Float.valueOf(line));
				        		//System.out.println("add biaoqzhisu");
				        	}
				        	i++;
				        	//fumianqingxu.add(line);
				        }
				        br.close();
		}catch(Exception ex){
			
			System.out.println(ex);
		}
	}
	
	public static void cdZS(){
		BufferedReader br=null;
		try {
			 br = new BufferedReader(new InputStreamReader
					 (new FileInputStream("./cidian/chengdujibie.txt")
					 ));
			 			int i =0;
				        for (String line = br.readLine(); line != null; line = br.readLine()) {
				        	StringTokenizer st = new StringTokenizer(line);
				        	if(st.hasMoreTokens()){
				        		line = st.nextToken();
				        	}
				        	if(i%2==0){
				        		chengdu.add(line);
				        		//System.out.println("add biaoq");
				        	}
				        	else{
				        		chengduzhisu.add(Float.valueOf(line));
				        		//System.out.println("add biaoqzhisu");
				        	}
				        	i++;
				        	//fumianqingxu.add(line);
				        }
				        br.close();
		}catch(Exception ex){
			
			System.out.println(ex);
		}
	}
	
	public static boolean isEnd(String end){
		for(String ends:saveW){
			if(end.endsWith(ends)){
				return true;
			}
		}
		return false;
	}
	
	
}
