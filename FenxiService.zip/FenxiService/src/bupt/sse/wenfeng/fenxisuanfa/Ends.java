package bupt.sse.wenfeng.fenxisuanfa;

import java.util.List;

public class Ends {
	public List<Float> fList = null;
	public String minString = null;
	public Float min = null;
	public Ends(List<Float> fList,String minString,Float min){
		this.fList = fList;
		this.minString = minString;
		this.min = min;
	}

}
