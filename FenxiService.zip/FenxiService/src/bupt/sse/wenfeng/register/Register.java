package bupt.sse.wenfeng.register;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import bupt.sse.wenfeng.startFX.StartFX;
import net.sf.json.JSONObject;
public class Register extends Thread{
	public String username=null;
	public String password = null;
	public Socket socket =null ;
	public String uid = null;
	public Register(String name,String password,String uid,Socket socket){
		this.username = name;
		this.password = password;
		this.socket = socket;
		this.uid = uid ;
	}
	
	public void run(){
		try {
		PrintWriter os=new PrintWriter(socket.getOutputStream());		
		IsRegister ir = new IsRegister(username,password);
		boolean done = ir.getIsR();
		JSONObject json = new JSONObject();
		if(done){
			json.put("cmd", 11);
			File file =new File("./users/"+username+".txt");
			if(file.exists()){

				file.delete();

			}
			file.createNewFile();
			FileWriter fileWritter = null;

			fileWritter = new FileWriter(file,true);
			PrintWriter pw = new PrintWriter(fileWritter);
			pw.println("赵一");
			pw.println("5101585588");
			pw.println("钱二");
			pw.println("2306277500");
			pw.println("张三");
			pw.println("2307271607");
			pw.println("李四");
			pw.println("2741315193");
			pw.flush();
			pw.close();
		}
		else{
			json.put("cmd", 10);
		}
		os.println(json.toString());
		os.flush();
		if(done){
			StartFX fx = new StartFX(uid);
			fx.getDatasByCssQueryUserBaidu(uid, "Baiduspider");
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
