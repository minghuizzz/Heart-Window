package bupt.sse.wenfeng.register;

import java.io.*;
import java.sql.*;
import java.net.Socket;
import java.util.*;

public class IsRegister {
private String name;
private String password;
private boolean isR=false;
private String  driver="com.mysql.jdbc.Driver";
private String address="jdbc:mysql://localhost:3306/xcmy";
public IsRegister(String name,String password){
	this.name=name;
	this.password=password;
	try{
		Class.forName(driver);
		System.out.println("链接成功");
		Connection connection=DriverManager.getConnection(address,"root","1234");
		Statement st=connection.createStatement();
		ResultSet rs=st.executeQuery("Select username from user where username='"+name+"'");
		if(rs.next()) isR=false;
		else  {st.execute("insert into user(username,password) value('"+name+"','"+password+"')");
		           isR=true;}
	}catch(Exception e){
		System.out.println("链接错误!");
		e.printStackTrace();
	}
	
}//IsRegister
	public boolean getIsR()
	{
		return isR;
	}
	
}
