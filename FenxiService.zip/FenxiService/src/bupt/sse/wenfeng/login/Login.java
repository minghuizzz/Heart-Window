package bupt.sse.wenfeng.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import net.sf.json.JSONObject;

public class Login extends Thread{
	public String name = null ;
	public String password =null;
	public Socket socket = null;
	public Login(String name,String password,Socket socket){
		this.name = name;
		this.password = password;
		this.socket = socket;
	}
	
	public void run(){
		PrintWriter os;
		try {
		os = new PrintWriter(socket.getOutputStream());		
		Ison io = new Ison(name,password);
		boolean done = io.getIson();
		JSONObject json = new JSONObject();
		if(done){
			json.put("cmd", 21);
		}
		else{
			json.put("cmd", 20);
		}
		os.println(json.toString());
		os.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
