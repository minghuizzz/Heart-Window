package bupt.sse.wenfeng.login;

import java.sql.*;
import java.util.Scanner;

public class Ison {
	private String name;
	private String password;
	private boolean isO=false;
	private String  driver="com.mysql.jdbc.Driver";
	private String  address="jdbc:mysql://localhost:3306/xcmy";
	public Ison(String name,String password){
		this.name=name;
		this.password=password;
		try{

			Class.forName(driver);//
			System.out.println("");
			Connection connect=DriverManager.getConnection(address,"root","1234");//
			Statement st=connect.createStatement();
			ResultSet rs=st.executeQuery("select username from user where username="+"'"
			+name+"' and password='"+password+"'");
			if(rs.next())isO=true;
		}//try
		catch(Exception e){
			System.out.println("");
			e.printStackTrace();
		}//catch
		
	}//Ison
	boolean getIson(){
		return isO;
		}
	

}

