package bupt.sse.wenfeng.core;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;  
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;  
import java.util.List;  
import java.util.Random;


import java.lang.String;
import org.jsoup.Connection;  
import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document;  
import org.jsoup.nodes.Element;  
import org.jsoup.select.Elements;   
import bupt.sse.wenfeng.rule.Rule;  
import bupt.sse.wenfeng.rule.RuleException;  
import bupt.sse.wenfeng.util.TextUtil;



public class ExtractService  
{  
	/** 
	 * @param rule 
	 * @return 
	 */  
	public static void extract(Rule rule)  
	{  
		validateRule(rule);   
		PrintWriter pw = null;
		String url = rule.getUrl();  
		String resultTagName = rule.getResultTagName();  
		int type = rule.getType();  
		int requestType = rule.getRequestMoethod();  
		String uuid = url;
		String agent=rule.getAgent();
		int pre_page=0;
		int pagenum=1;
		int pagebar=0;
		boolean hascontext=true;
		boolean has=false;
		File file = null;
		int countRead = 0;
		try {
			file =new File("./students/"+uuid+".txt");
			
			if(!file.exists()){

				file.createNewFile();

			}
			else{
				//file.delete();
				//file =new File("./students/"+uuid+".txt");
				//file.createNewFile();
				return;
			}
			FileWriter fileWritter = null;

			fileWritter = new FileWriter(file,true);
			pw = new PrintWriter(fileWritter);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int saveCount=0;
		int countTimeout=0;
		for(int trynum=0;trynum<3;){
			try  
			{
				for(int count=saveCount;count<3;count++){

					hascontext=true;
					String l ="http://weibo.com/u/"+uuid+"" +
							"?ajwvr=6&domain=100505&pre_page="+pre_page+"&page="+pagenum+"" +
							"&max_id=&end_id=3909786104242121&pagebar="+pagebar+
							"&filtered_min_id=&pl_name=Pl_Official_MyProfileFeed__22&id=1005052307271607&script_uri=/u/"+
							uuid+"&feed_type=0&domain_op=100505&__rnd=1448116299980";

					//System.out.println(l);
					//pw.println(l);
					Connection conn = Jsoup.connect(l);

					//conn.header("User-Agent", "spider");
					conn.header("User-Agent", agent);
					Random random1 = new Random();
					conn.header("X-Forwarded-For", random1.nextInt(254)+".0.0."+random1.nextInt(254));
					//System.out.println(IP);
					conn.method(Method.GET);

					Document doc = null;//;Jsoup.parse(pageContent)  
					switch (requestType)  
					{  
					case Rule.GET:  
						doc = conn.timeout(6000).get();  
						break;  
					case Rule.POST:  
						doc = conn.timeout(100000).post();  
						break;  
					}
					//System.out.println(doc);

					Elements results = new Elements();  
					switch (type)  
					{  
					case Rule.CLASS:  
						results = doc.getElementsByClass(resultTagName);  
						break;  
					case Rule.ID:  
						Element result = doc.getElementById(resultTagName);  
						results.add(result);  
						break;  
					case Rule.SELECTION:  
						results = doc.select(resultTagName);  
						break;  
					default:  
						//
						if (TextUtil.isEmpty(resultTagName))  
						{  
							results = doc.getElementsByTag("body");  
						}  
					}
					if(results.isEmpty()){
						trynum++;
						hascontext=false;
						System.out.println(uuid+"  nothing ,try again...");
						break;
						}
					has=true;
					
					for(Element e : results ){
						String wr = e.text();
						String get=getImg(e);
						if(get!=null){
							wr=wr+get;
						}
						//System.out.println(e.attr("node-type"));
						if(e.attr("node-type").equals("feed_list_reason")){
							wr="转发:"+wr;
							pw.println(wr);
						}
						else{
					//	pw.println();
						pw.println(wr);//e.toString()
						countRead++;
						if(countRead>29){
							break;
						}
						}
						
					}
					pw.flush();
					if(countRead>29){
						break;
					}
					if(count==0){
						pre_page=pagenum;
					}
					else if(count==1){
						pagebar++;
					}
					saveCount=count;


				}
			}

			catch (IOException e)  
			{  
				//pw.close();
				if(countTimeout>7){
					
					System.out.println(uuid +"  try more than 7,go to done...");
					break;
				}
				else{
				countTimeout++;
				hascontext=false;
				System.out.println(uuid +"  time out ,try again...");
				}
			}
			if(hascontext || countRead>29){
				countTimeout=0;
				trynum=0;
				saveCount=0;
				pre_page=0;
				pagebar=0;
				System.out.println(countRead);
				//pagenum++;
				break;
			}

		}
		pw.close();
		
		if(!has){
			//file
			file.delete();
		}
        System.out.println("Done");
		return ;
	}  
 
	private static void validateRule(Rule rule)  
	{  
		String url = rule.getUrl();  
		if (TextUtil.isEmpty(url))  
		{  
			throw new RuleException("url");  
		}  


	}
	private static String getImg(Element e){
		Elements t=e.getElementsByTag("img");
		if(t.isEmpty()) return null;
		String end="";
		for(Element getE:t){
			String atl=getE.attr("alt");
			if(atl.isEmpty()) break;
			end+=atl;
		}
		return end;
		}  
}  
