package bupt.sse.wenfeng.rule;

public class RuleException extends RuntimeException  
{  
  
    public RuleException()  
    {  
        super();  
        // TODO Auto-generated constructor stub  
    }  
  
    public RuleException(String message, Throwable cause)  
    {  
        super(message, cause);  
        // TODO Auto-generated constructor stub  
    }  
  
    public RuleException(String message)  
    {  
        super(message);  
        // TODO Auto-generated constructor stub  
    }  
  
    public RuleException(Throwable cause)  
    {  
        super(cause);  
        // TODO Auto-generated constructor stub  
    }  
  
}  
