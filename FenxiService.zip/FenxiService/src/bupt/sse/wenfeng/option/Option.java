package bupt.sse.wenfeng.option;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
public class Option {
	public JSONArray ja=null;
	public Option(JSONArray ja){
		this.ja = ja;
	}
	public Option(){}
	public JSONObject getLine(){
		String option = "{"+
    "title : {"+
        "text: '学生情绪走势图',"+
        "subtext: '正值代表积极情绪指数，负值代表消极情绪指数，0代表正常情绪'"+
    "},"+"animation:true,"+
    "tooltip : {"+
    "    trigger: 'axis'"+
    "},"+
    "legend: {"+
        "data:[]"+
    "},"+
    "toolbox: {"+
        "show : false,"+
       " feature : {"+
           " mark : {show: true},"+
            "dataView : {show: true, readOnly: false},"+
           " magicType : {show: false, type: ['line', 'bar', 'stack', 'tiled']},"+
           " restore : {show: true},"+
           " saveAsImage : {show: true}"+
      "  }"+
    "},"+
    "calculable : true,"+
   " xAxis : ["+
      "  {"+
           " type : 'category',"+
          "  boundaryGap : false,"+
          "  data : ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30']"+
        "}"+
   " ],"+
   " yAxis : ["+
     "   {"+
      "      type : 'value',"+"name:'情绪指数'"+
      "  }"+
   " ],"+
    "series : ["+
    "    {"+
           " name:'情绪指数',"+
           " type:'line',"+
           " smooth:true,"+
           " itemStyle: {normal: {areaStyle: {type: 'default'}}},"+
           " data:[10, 12, 21, 54, 26, 83, 71]"+
      "  }"+
  "  ]"+
"};"+
	"}"+
"}";
		JSONObject json = JSONObject.fromObject(option);
		System.out.println(json.getJSONArray("series").get(0));
		JSONObject js = (JSONObject) json.getJSONArray("series").get(0);
		js.remove("data");
		js.put("data", this.ja);
		JSONArray jsArray = new JSONArray();
		jsArray.add(js);
		json.remove("series");
		json.put("series", jsArray);
		//System.out.println(json.toString());
		//JSONArray ja = js.getJSONArray("data");
		//System.out.println(ja+" "+ja.getInt(0));
		return json;
	}
	
	public JSONObject getLine2(){
		String jstring = "{tooltip : {trigger: 'axis'},legend: {data:['情绪走势']},toolbox: {show : true,feature : {mark : {show: true},dataView : {show: true, readOnly: false},magicType : {show: true, type: ['line', 'bar', 'stack', 'tiled']},restore : {show: true},saveAsImage : {show: true}}},calculable : true,xAxis : [{type : 'category',boundaryGap : false,data : ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30']}],yAxis : [{type : 'value'}],series : [{name:'情绪走势',type:'line',stack: '总量',data:[120, 132, 101, 134, 90, 230, -210]}]}";
		JSONObject json = JSONObject.fromObject(jstring);
		System.out.println(json.getJSONArray("series").get(0));
		JSONObject js = (JSONObject) json.getJSONArray("series").get(0);
		js.remove("data");
		js.put("data", this.ja);
		JSONArray jsArray = new JSONArray();
		jsArray.add(js);
		json.remove("series");
		json.put("series", jsArray);
		//System.out.println(json.toString());
		//JSONArray ja = js.getJSONArray("data");
		//System.out.println(ja+" "+ja.getInt(0));
		return json;
	}
	
	public JSONObject getLine3(String text1,String text2,String text3,int num1,int num2,int num3,int allNum){
		int snum1 = allNum - num1;
		int snum2 = allNum - num2;
		int snum3 = allNum - num3;
		text1 = (Math.round((num1*1.00/allNum)*100*100)/100)+"%微博数据为积极情绪";
		text2 = (100-(Math.round((num1*1.00/allNum)*100*100)/100)-(Math.round((num3*1.00/allNum)*100*100)/100))+"%微博数据为正常情绪";
		text3 = (Math.round((num3*1.00/allNum)*100*100)/100)+"%微博数据为消极情绪";
		String option = "{"+
			    "title: {"+
	        "text: '学生情绪分布',"+
	        "x: 'center',"+
	        "y: 'center',"+
	        "itemGap: 20,"+
	        "textStyle : {"+
	            "color : 'rgba(30,144,255,0.8)',"+
	            "fontFamily : '微软雅黑',"+
	            "fontSize : 20,"+
	            "fontWeight : 'bolder'"+
	        "}"+
	    "},"+
	    "tooltip : {"+
	        "show: true,"+
	        "formatter: \"{a} <br/>{b} : {c} ({d}%)\""+//
	    "},"+
	    "legend: {"+
	        "orient : 'vertical',"+
	        "x : 2,"+
	        "y : 45,"+
	        "itemGap:12,"+
	        "data:[]"+//'"+text1+"','"+text2+"','"+text3+"'
	    "},"+
	    "toolbox: {"+
	       " show : true,"+
	        "feature : {"+
	           " mark : {show: true},"+
	            "dataView : {show: true, readOnly: false},"+
	            "restore : {show: true},"+
	            "saveAsImage : {show: true}"+
	        "}"+
	    "},"+
	    "series : ["+
	        "{"+
	            "name:'积极情绪',"+
	            "type:'pie',"+
	            "clockWise:false,"+
	            "radius : [100, 125],"+
	            "itemStyle : "+"{     normal: {         label: {show:false},         labelLine: {show:false}     } }"+","+
	            "data:["+
	            "{"+
                "value:"+num1+","+
                "name:'"+text1+"'"+
                		"},"+
	                
	                "{"+
	                    "value:"+snum1+","+
	                    "name:'invisible',"+//invisible
	                    "itemStyle : "+"{     normal : {         color: 'rgba(0,0,0,0)',         label: {show:false},         labelLine: {show:false}     },     emphasis : {         color: 'rgba(0,0,0,0)'     } }"+
	                "},"
	                    +"]},"+
	        "{"+
	           " name:'正常情绪',"+"type:'pie',clockWise:false,radius : [75, 100],itemStyle : "+"{     normal: {         label: {show:false},         labelLine: {show:false}     } }"+",data:[{"+
	                    "value:"+num2+"," +
	                    "name:'"+text2+"'"+
	                "},"+
	                "{"+
	                    "value:"+snum2+","+
	                    "name:'invisible',"+//invisible
	                    "itemStyle : "+"{     normal : {         color: 'rgba(0,0,0,0)',         label: {show:false},         labelLine: {show:false}     },     emphasis : {         color: 'rgba(0,0,0,0)'     } }"+
	                "}"+
	            "]"+
	        "},"+
	        "{"+
	            "name:'消极情绪',"+
	            "type:'pie',"+
	            "clockWise:false,"+
	            "radius : [50, 75],"+
	            "itemStyle : "+"{     normal: {         label: {show:false},         labelLine: {show:false}     } }"+","+
	            "data:["+
	                "{"+
	                    "value:"+num3+","+
	                    "name:'"+text3+"'"+
	                "},"+
	                "{"+
	                    "value:"+snum3+","+
	                    "name:'invisible',"+//"name:'',"+
	                    "itemStyle : "+"{     normal : {         color: 'rgba(0,0,0,0)',         label: {show:false},         labelLine: {show:false}     },     emphasis : {         color: 'rgba(0,0,0,0)'     } }"+
	                "}"+
	            "]"+
	        "}"+
	    "]"+
	"}";
		//option = ;
		JSONObject json = JSONObject.fromObject(option);
		return json;
	}
	
	public JSONObject getSan(int num1,int num2,int num3){
		String option = "{     tooltip : {         trigger: 'item',         formatter: \"{a} <br/>{b} : {c} ({d}%)\"     },       toolbox: {         show : true,         feature : {             mark : {show: true},             dataView : {show: true, readOnly: false},             magicType : {                 show: true,                 type: ['pie', 'funnel'],                 option: {                     funnel: {                         x: '25%',                         width: '50%',                         funnelAlign: 'center',                         max: 1548                     }                 }             },             restore : {show: true},             saveAsImage : {show: true}         }     },     calculable : true,     series : [         {             name:'访问来源',             type:'pie',             radius : ['50%', '70%'],             itemStyle : {                 normal : {                     label : {                         show : false                     },                     labelLine : {                         show : false                     }                 },                 emphasis : {                     label : {                         show : true,                         position : 'center',                         textStyle : {                             fontSize : '30',                             fontWeight : 'bold'                         }                     }                 }             },             data:[                 {value:"+num1+", name:'积极情绪'},                 {value:"+num2+", name:'正常情绪'},                 {value:"+num3+", name:'消极情绪'}             ]         }     ] };                     ";
		JSONObject json = JSONObject.fromObject(option);
		return json;
	}

}
