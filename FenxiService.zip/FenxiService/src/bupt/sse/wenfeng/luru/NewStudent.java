package bupt.sse.wenfeng.luru;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import net.sf.json.JSONObject;

public class NewStudent extends Thread{
	String name;
	String student;
	String uid;
	Socket socket;
	public NewStudent(String name,String student,String uid,Socket socket){
		this.name = name;
		this.student = student;
		this.uid = uid;
		this.socket = socket;
	}
public void run(){
	try {
	File fileall =new File("./users/"+name+".txt");
	FileWriter fileWritter = null;
	fileWritter = new FileWriter(fileall,true);	
	PrintWriter pw = new PrintWriter(fileWritter);
	pw.println(student);
	pw.println(uid);
	JSONObject json = new JSONObject();
	json.put("cmd", "51");
	PrintWriter os=new PrintWriter(socket.getOutputStream());
	os.println(json.toString());
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
