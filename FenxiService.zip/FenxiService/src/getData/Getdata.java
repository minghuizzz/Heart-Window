package getData;

public class Getdata {

}
