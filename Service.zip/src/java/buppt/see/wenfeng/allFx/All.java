/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package buppt.see.wenfeng.allFx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;

/**
 *
 * @author Feng
 */
public class All extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("some one come");
        response.setCharacterEncoding("UTF-8");
        String name = request.getParameter("username");
       // String password = request.getParameter("password");
        if(name==null){
        JSONObject json = new JSONObject();
        json.put("cmd",40);
        PrintWriter out = response.getWriter();
        out.println(json.toString());
        response.flushBuffer();
        return;
        }
        Socket socket = new Socket("127.0.0.1",4040);
        PrintWriter os=new PrintWriter(socket.getOutputStream());
        BufferedReader is=new BufferedReader(new InputStreamReader(socket.getInputStream(),"UTF-8"));
        JSONObject json = new JSONObject();
        json.put("cmd",4);
        json.put("username", name);
       // json.put("password", password);
        os.println(json.toString());
        os.flush();
        String s =is.readLine();
        System.out.println(s);
       // byte[] bytes = s.getBytes();
      //  String meg = new String(bytes,0,bytes.length,"UTF-8");
      //  System.out.println(meg);
        PrintWriter out = response.getWriter();
        out.println(s);
        os.close();
        is.close();
        socket.close();
        response.flushBuffer();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
