//JavaScript Framework 2.0 Code
try {
	Type.registerNamespace('com.yonyou.heartwindow.MyCareController');
	com.yonyou.heartwindow.MyCareController = function() {
		com.yonyou.heartwindow.MyCareController.initializeBase(this);
		this.initialize();
	}
	function com$yonyou$heartwindow$MyCareController$initialize() {

	}

	function com$yonyou$heartwindow$MyCareController$evaljs(js) {
		eval(js)
	}

	function getCare(sender, args) {
		var list = $cache.read("care");
		list = $stringToJSON(list);
		var json = {
			list : list
		}
		$ctx.push(json);

	}

	function getWeb(sender, args) {
		var row = $id("listviewdefine0").get("row");
		var uid = $stringToJSON(row).uid;
		$view.open({
			"viewid" : "com.yonyou.heartwindow.Search", //目标页面（首字母大写）全名，
			"animation-direction" : "right",
			"animation-time" : "500",
			"animation-type" : "Push",
			"isKeep" : "true",
			"uid" : uid
		});

	}

	function com$yonyou$heartwindow$MyCareController$button0_onclick(sender, args) {
		$view.open({
			"viewid" : "com.yonyou.heartwindow.My", //目标页面（首字母大写）全名，
			"animation-direction" : "right",
			"animation-time" : "500",
			"animation-type" : "Push",
			"isKeep" : "false",
		});
	}

	function com$yonyou$heartwindow$MyCareController$button1_onclick(sender, args) {

	}


	com.yonyou.heartwindow.MyCareController.prototype = {
		button1_onclick : com$yonyou$heartwindow$MyCareController$button1_onclick,
		button0_onclick : com$yonyou$heartwindow$MyCareController$button0_onclick,
		initialize : com$yonyou$heartwindow$MyCareController$initialize,
		evaljs : com$yonyou$heartwindow$MyCareController$evaljs
	};
	com.yonyou.heartwindow.MyCareController.registerClass('com.yonyou.heartwindow.MyCareController', UMP.UI.Mvc.Controller);
} catch(e) {
	$e(e);
}
