//JavaScript Framework 2.0 Code
try {
	Type.registerNamespace('com.yonyou.heartwindow.SearchController');
	com.yonyou.heartwindow.SearchController = function() {
		com.yonyou.heartwindow.SearchController.initializeBase(this);
		this.initialize();
	}
	function com$yonyou$heartwindow$SearchController$initialize() {

	}

	function com$yonyou$heartwindow$SearchController$evaljs(js) {
		eval(js)
	}

	function com$yonyou$heartwindow$SearchController$button0_onclick(sender, args) {

		$view.close();

	}

	function toweb() {
		$js.hideLoadingBar();
		var result = $ctx.param("result");
		//alert(result);
		result = $stringToJSON(result);
		//alert(result);
		if (!result) {
			alert("链接失败，请检查网络后再次尝试");
			return;
		}
		var uid = result.uid;
		var lineOption = result.lineOption;
		var sanArray = result.sanOption;
		var careCount = result.xiaoji;
		var allCount = result.count;
		var saveR = $jsonToString(result);
		$cache.write(uid, saveR);
		lineOption = $jsonToString(lineOption);
		sanArray = $jsonToString(sanArray);
		$cache.write("searchL", lineOption);
		$cache.write("searchS", sanArray);
		$cache.write("searchCCount", careCount);
		$cache.write("searchACount", allCount);

		$js.runjs({
			"controlid" : "webcontrol0", //webControl的id
			"func" : "drawLine3()"//要执行位于webControl中的js方法名
		});
		$js.runjs({
			"controlid" : "webcontrol1", //webControl的id
			"func" : "drawLine3()"//要执行位于webControl中的js方法名
		});
		$id("label0").set("text", "微博总数：" + allCount);
		$id("label1").set("text", "情绪低于预警总数：" + careCount);
	}

	var uid;
	function loadEmotionDetail(sender, args) {
		/*
		 var uid = $id("textbox0").get("value");
		 if (!uid) {
		 alert("请输入微博号");
		 }

		 */
		uid = $param.getString("uid");

		$service.post({
			"url" : "http://123.103.9.193:9066/service/Service",
			"data" : {
				"uid" : uid
			},
			"callback" : "toweb()",
			"timeout" : 240
		});
		$js.showLoadingBar();
	}

	function com$yonyou$heartwindow$SearchController$button3_onclick(sender, args) {

	
		$view.open({
			"viewid" : "com.yonyou.heartwindow.MyCareWeb", //目标页面（首字母大写）全名，
			"animation-direction" : "right",
			"animation-time" : "500",
			"animation-type" : "Push",
			"isKeep" : "true",
			"uid" : uid
		});

	}
	com.yonyou.heartwindow.SearchController.prototype = {
		button3_onclick : com$yonyou$heartwindow$SearchController$button3_onclick,
		button0_onclick : com$yonyou$heartwindow$SearchController$button0_onclick,
		initialize : com$yonyou$heartwindow$SearchController$initialize,
		evaljs : com$yonyou$heartwindow$SearchController$evaljs
	};
	com.yonyou.heartwindow.SearchController.registerClass('com.yonyou.heartwindow.SearchController', UMP.UI.Mvc.Controller);
} catch(e) {
	$e(e);
}
