//JavaScript Framework 2.0 Code
try {
	Type.registerNamespace('com.yonyou.heartwindow.MainController');
	com.yonyou.heartwindow.MainController = function() {
		com.yonyou.heartwindow.MainController.initializeBase(this);
		this.initialize();
	}
	function com$yonyou$heartwindow$MainController$initialize() {

	}

	function com$yonyou$heartwindow$MainController$evaljs(js) {
		eval(js)
	}

	var result;

	function com$yonyou$heartwindow$MainController$viewPage0_onload(sender, args) {
		/* 端口能通  但是需要时间太长
		 $service.post({
		 "url" : "http://123.103.9.193:9066/service/All",
		 "data" : {"username":"all"},
		 "callback" : "toFenxi()",
		 "timeout" :240
		 });
		 $js.showLoadingBar();
		 */
		$js.showLoadingBar();

		//var result = {"cmd":"41","lineOption":{"backgroundColor":"rgba(255,255,255,1)","color":["#87cefa"],"grid":{"x":15,"y":25,"x2":15,"y2":25},"tooltip":{"trigger":"axis"},"calculable":true,"xAxis":[{"type":"category","boundaryGap":false,"data":["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"]}],"yAxis":[{"type":"value","name":"情绪指数"}],"series":[{"name":"情绪指数","type":"line","smooth":true,"itemStyle":{"normal":{"areaStyle":{"type":"default"}}},"data":[0,1,1,0.5,0.5,1,2,1,0,0,1,1,0,0,1,1,2,1,1,0.5,0.5,0,1,1,3,2,2,1,0,1]}]},"sanOption":{"backgroundColor":"rgba(255,255,255,1)","tooltip":{"trigger":"item","formatter":"{a} <br/>{b} : {c} ({d}%)"},"calculable":true,"series":[{"name":"情绪指数","type":"pie","radius":["50%","70%"],"itemStyle":{"normal":{"label":{"show":false},"labelLine":{"show":false}},"emphasis":{"label":{"show":true,"position":"center","textStyle":{"fontSize":"30","fontWeight":"bold"}}}},"data":[{"value":842,"name":"积极情绪"},{"value":526,"name":"正常情绪"},{"value":234,"name":"消极情绪"}]}]},"allCount":526,"careLength":31};
		result = {
			"cmd" : "41",
			"lineOption" : {
				"name" : "情绪走势",
				"data" : [0, 1, 1, 0.5, 0.5, 1, 2, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 1, 1, 0.5, 0.5, 0, 1, 1, 3, 2, 2, 1, 0, 1]
			},
			"sanOption" : {
				"name" : "情绪分布",
				"data" : [["积极情绪", 8314], ["正常情绪", 5247], ["消极情绪", 2214]]
			},
			"allCount" : 526,
			"careLength" : 31
		};
		var linearray = result.lineOption;
		//折线图option
		var sanArray = result.sanOption;
		//条形图option

		var stringArray = $jsonToString(linearray);
		var sanArray = $jsonToString(sanArray);

		$cache.write("alllineOption", "");
		$cache.write("allcareCount", "");
		$cache.write("allallCount", "");
		$cache.write("allsanOption", "");

		$cache.write("alllineOption", stringArray);
		$cache.write("allcareCount", careCount);
		$cache.write("allallCount", allCount);
		$cache.write("allsanOption", sanArray);
		$ctx.put("allsanOption1", sanArray);
		$ctx.setApp({
			"allsanOption2" : sanArray
		});
		//$alert($cache.read("allsanOption"));
		//$alert($ctx.getApp("allsanOption2"));

		$js.runjs({
			"controlid" : "webcontrol1", //webControl的id
			"func" : "drawLine2()"//要执行位于webControl中的js方法名
		});
		var careCount = result.careLength;
		//情绪低落学生  json数组，包含数据 name,uid ,context
		var allCount = result.allCount;
		$id("label0").set("text", "样本总数：" + allCount);
		$id("label1").set("text", "情绪低于预警人数：" + careCount);

		setTimeout(function() {
			$js.runjs({
				"controlid" : "webcontrol0", //webControl的id
				"func" : "drawLine2()"//要执行位于webControl中的js方法名
			});

			$js.hideLoadingBar();
		}, 1000);

	}

	function com$yonyou$heartwindow$MainController$label1_onclick(sender, args) {

	}

	function com$yonyou$heartwindow$MainController$button1_onclick(sender, args) {
		$view.open({
			"viewid" : "com.yonyou.heartwindow.My", //目标页面（首字母大写）全名，
			"animation-direction" : "right",
			"animation-time" : "500",
			"animation-type" : "Push",
			"isKeep" : "false",
		});
	}

	function com$yonyou$heartwindow$MainController$button2_onclick(sender, args) {
		$view.open({
			"viewid" : "com.yonyou.heartwindow.SearchHot", //目标页面（首字母大写）全名，
			"animation-direction" : "right",
			"animation-time" : "500",
			"animation-type" : "Push",
			"isKeep" : "true",
		});
	}


	com.yonyou.heartwindow.MainController.prototype = {
		button2_onclick : com$yonyou$heartwindow$MainController$button2_onclick,
		button1_onclick : com$yonyou$heartwindow$MainController$button1_onclick,
		label1_onclick : com$yonyou$heartwindow$MainController$label1_onclick,
		viewPage0_onload : com$yonyou$heartwindow$MainController$viewPage0_onload,
		initialize : com$yonyou$heartwindow$MainController$initialize,
		evaljs : com$yonyou$heartwindow$MainController$evaljs
	};
	com.yonyou.heartwindow.MainController.registerClass('com.yonyou.heartwindow.MainController', UMP.UI.Mvc.Controller);
} catch(e) {
	$e(e);
}
