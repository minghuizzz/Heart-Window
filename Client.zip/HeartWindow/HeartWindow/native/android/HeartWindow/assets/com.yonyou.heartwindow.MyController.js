//JavaScript Framework 2.0 Code
try{
Type.registerNamespace('com.yonyou.heartwindow.MyController');
com.yonyou.heartwindow.MyController = function() {
    com.yonyou.heartwindow.MyController.initializeBase(this);
    this.initialize();
}
function com$yonyou$heartwindow$MyController$initialize(){
    //you can programing by $ctx API
    //get the context data through $ctx.get()
    //set the context data through $ctx.push(json)
    //set the field of the context through $ctx.put(fieldName, fieldValue)
    //get the parameter of the context through $ctx.param(parameterName)
    //Demo Code:
    //    var str = $ctx.getString();      //获取当前Context对应的字符串
    //    alert($ctx.getString())          //alert当前Context对应的字符串
    //    var json = $ctx.getJSONObject(); //获取当前Context，返回值为json
    //    json["x"] = "a";        //为当前json增加字段
    //    json["y"] = [];           //为当前json增加数组
    //    $ctx.push(json);            //设置context，并自动调用数据绑定
    //    
    //    put方法需手动调用databind()
    //    var x = $ctx.get("x");    //获取x字段值
    //    $ctx.put("x", "b");     //设置x字段值
    //    $ctx.put("x", "b");     //设置x字段值
    //    $ctx.databind();            //调用数据绑定才能将修改的字段绑定到控件上
    //    var p1 = $param.getString("p1");   //获取参数p2的值，返回一个字符串
    //    var p2 = $param.getJSONObject("p2");   //获取参数p3的值，返回一个JSON对象
    //    var p3 = $param.getJSONArray("p3");   //获取参数p1的值，返回一个数组
    
    //your initialize code below...
    
}
    
function com$yonyou$heartwindow$MyController$evaljs(js){
    eval(js)
}
function com$yonyou$heartwindow$MyController$viewPage0_onload(sender, args){

var care = $cache.read("care");
if(!care){
$service.post({
		         "url" : "http://123.103.9.193:9066/service/All",
		         "data" : {"username":"q"},
		         "callback" : "MyFenxi()",
		         "timeout" :240
		    	});
		    	$js.showLoadingBar();
		    }
else{
	var allCount = $cache.read("allCount");
	var careCount = $cache.read("careCount");
	$id("label0").set("text", "样本总数："+allCount);
	$id("label1").set("text", "情绪低于预警人数："+careCount);
	$js.runjs({
    "controlid" : "webcontrol0",//webControl的id
    "func" : "drawLine()"//要执行位于webControl中的js方法名
	});
	
	$js.runjs({
   	 	"controlid" : "webcontrol1",//webControl的id
    		"func" : "drawLine()"//要执行位于webControl中的js方法名
	});
}


//MyFenxi();
}
function MyFenxi(){
	$js.hideLoadingBar();
	var result = $ctx.param("result");
//var result={"cmd":"41","lineOption":{"name":"情绪走势","data":[2.120107650756836,0.38796472549438477,0.31489086151123047,0.9136782288551331,0.24561865627765656,0.9222346544265747,0.9978067278862,0.4238806664943695,0.48150062561035156,1.125349998474121,1.0191066265106201,1.3848849534988403,1.086796760559082,-0.16029182076454163,0.08197297155857086,0.46807950735092163,0.4339739680290222,0.2309098094701767,0.6455199122428894,0.3390082120895386,0.608805775642395,0.21349403262138367,0.7041712999343872,1.115639090538025,-0.11578032374382019,0.5835326910018921,0.7827121019363403,0.2903292179107666,0.3103223145008087,0.3070228695869446]},"sanOption":{"name":"情绪分布","data":[["积极情绪",390],["正常情绪",190],["消极情绪",79]]},"students":[{"name":"梁馨","uid":"5101585588"},{"name":"张家杰","uid":"2306277500"},{"name":"暴智伟","uid":"2307271607"},{"name":"文峰","uid":"2741315193"},{"name":"阎硕","uid":"2771090183"},{"name":"曹潇","uid":"2761079631"},{"name":"康子农","uid":"2771070893"},{"name":"李桂洪","uid":"2761077273"},{"name":"朱明晖","uid":"2781079801"},{"name":"张三","uid":"2781058393"},{"name":"李四","uid":"2781058437"},{"name":"王五","uid":"2781058441"},{"name":"林俊杰","uid":"2781058443"},{"name":"龙蛟","uid":"2781058450"},{"name":"卢竞","uid":"2781058455"},{"name":"李晨一","uid":"2781058467"},{"name":"林心如","uid":"2781058471"},{"name":"杨景生","uid":"2781058480"},{"name":"马小云","uid":"2781058483"},{"name":"周杰伦","uid":"2781058507"},{"name":"王茂凯","uid":"2781058513"},{"name":"陈坤","uid":"2781058517"},{"name":"谢霆锋","uid":"2781058537"},{"name":"黄磊","uid":"2781058567"},{"name":"李晨","uid":"2781058575"},{"name":"邓超","uid":"2781058585"},{"name":"李毅","uid":"2781058591"},{"name":"王佳怡","uid":"2781058593"},{"name":"彩丰行","uid":"2781058601"},{"name":"谢坤","uid":"2781058602"},{"name":"牛磊","uid":"2781058607"},{"name":"牛烨","uid":"2781058610"},{"name":"梁晨","uid":"2781058631"},{"name":"文海山","uid":"2781058633"}],"care":[{"name":"梁馨","context":"我现在最后悔的事就是！！在来北京前没有练成龟息大法[感冒]","uid":"5101585588"},{"name":"康子农","context":"回忆是所有心痛的根源。如若不曾有回忆，就不会有那么多甜美的画面，如果不曾有回忆，也不会有那么多失望的眼泪……心不动，则不痛。——默默冉《余光》","uid":"2771070893"},{"name":"朱明晖","context":"不吃肉怎么行 最近肉不够吃好心酸","uid":"2781079801"},{"name":"张三","context":"讨厌出差，讨厌出差，讨厌出差…… 2G92杭州湾环线高速","uid":"2781058393"},{"name":"龙蛟","context":"我刚更新了#超级课程表#Android客户端4.4版本。新东方创始人徐小平老师倾力代言！校园官方认证，对接高校教务系统，快速录入课表到手机。自动推荐千万节旁听课程，跨院系蹭课！搭讪课堂周围的同学，在线互传纸条。更聚集了数百万的大学生匿名吐槽！快来加入我：S超级课程表","uid":"2781058450"},{"name":"周杰伦","context":"也许最沉重的负担同时也是一种生活最为充实的象征，负担越沉，我们的生活也就越贴近大地，越趋近真切和实在。","uid":"2781058507"},{"name":"陈坤","context":"女儿的心声:真没想到，你居然下的了口，在你那轻轻地一吻之后，我就已经把你深深的记在了心里，你这讨厌的蚊子。","uid":"2781058517"},{"name":"谢霆锋","context":"悲催#热门微博# O网页链接","uid":"2781058537"},{"name":"李毅","context":"昨晚，唐慧在电话中告知早报记者，她不服这一结果，将循行政诉讼的方式“讨回公道”，湖南省政法委承诺组织调查组彻查其女儿被逼卖淫案，但从去年8月至今，调查组从未约见她和女儿，唐慧将于明天主动前往湖南省政法委，检举永州市零陵区分局干警雷某、永州市交警支队民警刘某在乐乐受害案中奸淫幼女。","uid":"2781058591"},{"name":"牛磊","context":"6 9 遗憾","uid":"2781058607"},{"name":"梁晨","context":"明晚8点 //@南派三叔:十年一瞬，回望起程！准备吐槽。在这里热身。","uid":"2781058631"}],"allCount":34,"careLength":11};

	//alert(result);
	result = $stringToJSON(result);
	if(!result){
		alert("链接失败，请检查网络后再次尝试");
		return;
	}
	var array =result.lineOption;//折线图option
	var sanArray = result.sanOption;//条形图option
	var careCount = result.careLength;//情绪低落学生  json数组，包含数据 name,uid ,context
	var allCount = result.allCount;
	var students = result.students;
	var care = result.care;
	
	var stringArray = $jsonToString(array);
	sanArray = $jsonToString(sanArray);
	$cache.write("lineOption", stringArray);
	$cache.write("careCount", careCount);
	$cache.write("allCount", allCount);
	$cache.write("sanOption", sanArray);
	
	students = $jsonToString(students);
	care = $jsonToString(care);
	$cache.write("students", students);
	$cache.write("care", care);
	
	
	$js.runjs({
    "controlid" : "webcontrol0",//webControl的id
    "func" : "drawLine()"//要执行位于webControl中的js方法名
	});
	$js.runjs({
   	 	"controlid" : "webcontrol1",//webControl的id
    		"func" : "drawLine()"//要执行位于webControl中的js方法名
	});
	$id("label0").set("text", "样本总数："+allCount);
	$id("label1").set("text", "情绪低于预警人数："+careCount);
}
function com$yonyou$heartwindow$MyController$button0_onclick(sender, args){
$view.open({
			"viewid" : "com.yonyou.heartwindow.Main",//目标页面（首字母大写）全名，
			"animation-direction":"right",
			"animation-time":"500",
			"animation-type":"Push",
			"isKeep" : "false",
		    });
}
function com$yonyou$heartwindow$MyController$label1_onclick(sender, args){
$view.open({
			"viewid" : "com.yonyou.heartwindow.MyCare",//目标页面（首字母大写）全名，
			"animation-direction":"right",
			"animation-time":"500",
			"animation-type":"Push",
			"isKeep" : "false",
		    });
}
function com$yonyou$heartwindow$MyController$button5_onclick(sender, args){
$view.open({
			"viewid" : "com.yonyou.heartwindow.AddStudent",//目标页面（首字母大写）全名，
			"animation-direction":"right",
			"animation-time":"500",
			"animation-type":"Push",
			"isKeep" : "false",
			"tag":"myAdd"
		    });
}
function com$yonyou$heartwindow$MyController$button4_onclick(sender, args){
$view.open({
			"viewid" : "com.yonyou.heartwindow.Students",//目标页面（首字母大写）全名，
			"animation-direction":"right",
			"animation-time":"500",
			"animation-type":"Push",
			"isKeep" : "false",
		    });
}
function com$yonyou$heartwindow$MyController$button2_onclick(sender, args){
$view.open({
			"viewid" : "com.yonyou.heartwindow.SearchHot",//目标页面（首字母大写）全名，
			"animation-direction":"right",
			"animation-time":"500",
			"animation-type":"Push",
			"isKeep" : "true",
		    });
}
com.yonyou.heartwindow.MyController.prototype = {
    button2_onclick : com$yonyou$heartwindow$MyController$button2_onclick,
    button4_onclick : com$yonyou$heartwindow$MyController$button4_onclick,
    button5_onclick : com$yonyou$heartwindow$MyController$button5_onclick,
    label1_onclick : com$yonyou$heartwindow$MyController$label1_onclick,
    button0_onclick : com$yonyou$heartwindow$MyController$button0_onclick,
    viewPage0_onload : com$yonyou$heartwindow$MyController$viewPage0_onload,
    initialize : com$yonyou$heartwindow$MyController$initialize,
    evaljs : com$yonyou$heartwindow$MyController$evaljs
};
com.yonyou.heartwindow.MyController.registerClass('com.yonyou.heartwindow.MyController',UMP.UI.Mvc.Controller);
}catch(e){$e(e);}
