//JavaScript Framework 2.0 Code
try {
	Type.registerNamespace('com.yonyou.heartwindow.AddStudentController');
	com.yonyou.heartwindow.AddStudentController = function() {
		com.yonyou.heartwindow.AddStudentController.initializeBase(this);
		this.initialize();
	}
	function com$yonyou$heartwindow$AddStudentController$initialize() {

	}

	function com$yonyou$heartwindow$AddStudentController$evaljs(js) {
		eval(js)
	}

	var tag;

	function com$yonyou$heartwindow$AddStudentController$button1_onclick(sender, args) {
		var name = $id("textbox0").get("value");
		var uid = $id("textbox1").get("value");
		if (!name || !uid) {
			alert("请输入完整的信息");
		}

		$service.post({
			"url" : "http://123.103.9.193:9066/service/NewStudent",
			"data" : {
				"username" : "q",
				"student" : name,
				"uid" : uid
			},
			"callback" : "toNew()",
			"timeout" : 240
		});
		$js.showLoadingBar();
	}

	function toNew() {
		$js.hideLoadingBar();
		var result = $ctx.param("result");
		//alert(result);
		result = $stringToJSON(result);
		if (!result) {
			alert("链接失败，请检查网络后再次尝试");
			return;
		}
		if (result.cmd == 50) {
			alert("录入失败");
		} else {
			var name = $id("textbox0").get("value");
			var uid = $id("textbox1").get("value");
			var json = {
				"name" : name,
				"uid" : uid
			}
			var data = $cache.read("students");
			data = $stringToJSON(data);
			data.push(json);
			data = $jsonToString(data);
			$cache.write("students", data);
			alert("录入成功");

			viewClose();

		}
	}
	function viewClose(){
		if (tag == "myAdd") {
			$view.open({
				"viewid" : "com.yonyou.heartwindow.My", //目标页面（首字母大写）全名，
				"animation-direction" : "right",
				"animation-time" : "500",
				"animation-type" : "Push",
				"isKeep" : "false",
			});
		} else if (tag == "stuListAdd") {
			$view.open({
				"viewid" : "com.yonyou.heartwindow.Students", //目标页面（首字母大写）全名，
				"animation-direction" : "right",
				"animation-time" : "500",
				"animation-type" : "Push",
				"isKeep" : "false",
			});
		}
	}

	function com$yonyou$heartwindow$AddStudentController$button0_onclick(sender, args) {
		viewClose();

	}

	function loadTag(sender, args) {
		tag = $param.getString("tag");

	}


	com.yonyou.heartwindow.AddStudentController.prototype = {
		button0_onclick : com$yonyou$heartwindow$AddStudentController$button0_onclick,
		button1_onclick : com$yonyou$heartwindow$AddStudentController$button1_onclick,
		initialize : com$yonyou$heartwindow$AddStudentController$initialize,
		evaljs : com$yonyou$heartwindow$AddStudentController$evaljs
	};
	com.yonyou.heartwindow.AddStudentController.registerClass('com.yonyou.heartwindow.AddStudentController', UMP.UI.Mvc.Controller);
} catch(e) {
	$e(e);
}
