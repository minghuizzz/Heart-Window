package com.yonyou.heartwindow;

import com.yonyou.uap.um.application.ApplicationContext;
import com.yonyou.uap.um.base.*;
import com.yonyou.uap.um.common.*;
import com.yonyou.uap.um.third.*;
import com.yonyou.uap.um.control.*;
import com.yonyou.uap.um.core.*;
import com.yonyou.uap.um.binder.*;
import com.yonyou.uap.um.runtime.*;
import com.yonyou.uap.um.lexer.*;
import com.yonyou.uap.um.widget.*;
import com.yonyou.uap.um.widget.UmpSlidingLayout.SlidingViewType;
import com.yonyou.uap.um.log.ULog;
import java.util.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.webkit.*;
import android.content.*;
import android.graphics.*;
import android.widget.ImageView.ScaleType;

public abstract class SearchActivity extends UMWindowActivity {

	protected UMWindow Search = null;
protected XVerticalLayout viewPage0 = null;
protected XHorizontalLayout panel0 = null;
protected UMButton button0 = null;
protected UMLabel label4 = null;
protected UMButton button3 = null;
protected UMLabel label0 = null;
protected XHorizontalLayout panel1 = null;
protected UMWebView webcontrol0 = null;
protected XHorizontalLayout panel3 = null;
protected XHorizontalLayout panel4 = null;
protected UMLabel label3 = null;
protected XHorizontalLayout panel5 = null;
protected UMWebView webcontrol1 = null;

	
	protected final static int ID_SEARCH = 602790582;
protected final static int ID_VIEWPAGE0 = 2024270424;
protected final static int ID_PANEL0 = 435333643;
protected final static int ID_BUTTON0 = 163976743;
protected final static int ID_LABEL4 = 1750669520;
protected final static int ID_BUTTON3 = 1594295152;
protected final static int ID_LABEL0 = 237644591;
protected final static int ID_PANEL1 = 1768890384;
protected final static int ID_WEBCONTROL0 = 173802680;
protected final static int ID_PANEL3 = 552204426;
protected final static int ID_PANEL4 = 1060838150;
protected final static int ID_LABEL3 = 44407139;
protected final static int ID_PANEL5 = 253783818;
protected final static int ID_WEBCONTROL1 = 277221796;

	
	
	@Override
	public String getControllerName() {
		return "SearchController";
	}
	
	@Override
	public String getContextName() {
		return "";
	}

	@Override
	public String getNameSpace() {
		return "com.yonyou.heartwindow";
	}

	protected void onCreate(Bundle savedInstanceState) {
		ULog.logLC("onCreate", this);
		super.onCreate(savedInstanceState);
        onInit(savedInstanceState);
        
	}
	
	@Override
	protected void onStart() {
		ULog.logLC("onStart", this);
		
		super.onStart();
	}

	@Override
	protected void onRestart() {
		ULog.logLC("onRestart", this);
		
		super.onRestart();
	}

	@Override
	protected void onResume() {
		ULog.logLC("onResume", this);
		
		super.onResume();
	}

	@Override
	protected void onPause() {
		ULog.logLC("onPause", this);
		
		super.onPause();
	}

	@Override
	protected void onStop() {
		ULog.logLC("onStop", this);
		
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		ULog.logLC("onDestroy", this);
		
		super.onDestroy();
	}
	
	public  void onInit(Bundle savedInstanceState) {
		ULog.logLC("onInit", this);
		UMActivity context = this;
		registerControl();
		this.getContainer();
		
		/*
		 new Thread() {
			 public void run() {
				 UMPDebugClient.startServer();
			 }
		 }.start();
		*/
		String sys_debug = ApplicationContext.getCurrent(this).getValue("sys_debug");
		if (sys_debug != null && sys_debug.equalsIgnoreCase("true")) {
			UMPDebugClient.waitForDebug();
		}

		IBinderGroup binderGroup = this;
		currentPage = getCurrentWindow(context, binderGroup);
super.setContentView(currentPage);

		
	}
	
	private void registerControl() {
		  idmap.put("Search",ID_SEARCH);
  idmap.put("viewPage0",ID_VIEWPAGE0);
  idmap.put("panel0",ID_PANEL0);
  idmap.put("button0",ID_BUTTON0);
  idmap.put("label4",ID_LABEL4);
  idmap.put("button3",ID_BUTTON3);
  idmap.put("label0",ID_LABEL0);
  idmap.put("panel1",ID_PANEL1);
  idmap.put("webcontrol0",ID_WEBCONTROL0);
  idmap.put("panel3",ID_PANEL3);
  idmap.put("panel4",ID_PANEL4);
  idmap.put("label3",ID_LABEL3);
  idmap.put("panel5",ID_PANEL5);
  idmap.put("webcontrol1",ID_WEBCONTROL1);

	}
	
	public void onLoad() {
		ULog.logLC("onLoad", this);
		if(currentPage!=null) {
			currentPage.onLoad();
		}
	
		{ //viewPage0 - action:viewpage0_onload
    UMEventArgs args = new UMEventArgs(SearchActivity.this);
    actionViewpage0_onload(viewPage0,args);

}

	}
	
	public void onDatabinding() {
		ULog.logLC("onDatabinding", this);
		super.onDatabinding();
		
	}
	
	@Override
	public void onReturn(String methodName, Object returnValue) {
		
	}

	@Override
	public void onAfterInit() {
		ULog.logLC("onAfterInit", this);
		
		onLoad();
	}
	
		@Override
	public Map<String,String> getPlugout(String id) {
		XJSON from = this.getUMContext();
		Map<String,String> r = super.getPlugout(id);
		
		return r;	
	}
	
	
	
	public View getPanel0View(final UMActivity context,IBinderGroup binderGroup) {
panel0 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL0
,"padding-left","8"
,"padding-right","8"
,"halign","LEFT"
,"height","45"
,"layout-type","vbox"
,"background","#79c7c5"
,"width","fill"
,"valign","center"
);
button0 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON0
,"halign","center"
,"pressed-image","backhover.png"
,"width","22.0"
,"font-pressed-color","#f2adb2"
,"height","22"
,"color","#e50011"
,"font-size","17"
,"layout-type","hbox"
,"onclick","action:button0_onclick"
,"font-family","default"
,"valign","center"
,"background-image","back.png"
);
panel0.addView(button0);
label4 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL4
,"halign","center"
,"weight","1"
,"width","0"
,"font-weight","bold"
,"content","情绪分析"
,"height","wrap"
,"color","#ffffff"
,"heightwrap","25.0"
,"font-size","17"
,"layout-type","hbox"
,"font-family","default"
,"valign","center"
);
panel0.addView(label4);
button3 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON3
,"halign","center"
,"widthwrap","108.0"
,"width","wrap"
,"font-pressed-color","#f2adb2"
,"height","44"
,"color","#ffffff"
,"font-size","17"
,"layout-type","hbox"
,"value","查看微博详情"
,"onclick","action:button3_onclick"
,"font-family","default"
,"valign","center"
);
panel0.addView(button3);

return panel0;
}
public View getPanel1View(final UMActivity context,IBinderGroup binderGroup) {
panel1 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL1
,"halign","LEFT"
,"height","0"
,"weight","4"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","center"
);
webcontrol0 = (UMWebView)ThirdControl.createControl(new UMWebView(context),ID_WEBCONTROL0
,"halign","center"
,"startpage","examples/pie-basic/myPie.html"
,"height","fill"
,"layout-type","hbox"
,"layout","vbox"
,"width","fill"
,"valign","TOP"
,"url","file:///android_asset/webcontrol/Highcharts/examples/pie-basic/myPie.html"
);
panel1.addView(webcontrol0);

return panel1;
}
public View getPanel4View(final UMActivity context,IBinderGroup binderGroup) {
panel4 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL4
,"halign","LEFT"
,"height","30"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"margin-top","10"
,"valign","center"
);
label3 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL3
,"content","情绪走势"
,"halign","center"
,"height","fill"
,"widthwrap","72.0"
,"color","#9b9b9b"
,"layout-type","hbox"
,"font-size","17"
,"width","wrap"
,"margin-left","20"
,"font-family","default"
,"valign","center"
);
panel4.addView(label3);

return panel4;
}
public View getPanel5View(final UMActivity context,IBinderGroup binderGroup) {
panel5 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL5
,"halign","LEFT"
,"height","0"
,"weight","3"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","center"
);
webcontrol1 = (UMWebView)ThirdControl.createControl(new UMWebView(context),ID_WEBCONTROL1
,"halign","center"
,"startpage","examples/area-basic/myLine.html"
,"height","fill"
,"layout-type","hbox"
,"layout","vbox"
,"width","fill"
,"valign","TOP"
,"url","file:///android_asset/webcontrol/Highcharts/examples/area-basic/myLine.html"
);
panel5.addView(webcontrol1);

return panel5;
}
public View getViewPage0View(final UMActivity context,IBinderGroup binderGroup) {
viewPage0 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_VIEWPAGE0
,"halign","center"
,"height","fill"
,"onload","action:viewpage0_onload"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","TOP"
);
View panel0 = (View) getPanel0View((UMActivity)context,binderGroup);
viewPage0.addView(panel0);
label0 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL0
,"content","微博总数："
,"halign","left"
,"height","20"
,"color","#808080"
,"layout-type","vbox"
,"font-size","14"
,"background","#ffffff"
,"width","fill"
,"margin-left","8"
,"font-family","default"
,"valign","center"
);
viewPage0.addView(label0);
View panel1 = (View) getPanel1View((UMActivity)context,binderGroup);
viewPage0.addView(panel1);
panel3 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL3
,"halign","LEFT"
,"height","1"
,"layout-type","vbox"
,"background","#c0c0c0"
,"width","fill"
,"margin-top","20"
,"valign","center"
);
viewPage0.addView(panel3);
View panel4 = (View) getPanel4View((UMActivity)context,binderGroup);
viewPage0.addView(panel4);
View panel5 = (View) getPanel5View((UMActivity)context,binderGroup);
viewPage0.addView(panel5);

return viewPage0;
}
public UMWindow getCurrentWindow(final UMActivity context,IBinderGroup binderGroup) {
Search = (UMWindow)ThirdControl.createControl(new UMWindow(context),ID_SEARCH
,"halign","center"
,"height","fill"
,"layout-type","linear"
,"layout","vbox"
,"width","fill"
,"controller","SearchController"
,"valign","TOP"
,"namespace","com.yonyou.heartwindow"
);
View viewPage0 = (View) getViewPage0View((UMActivity)context,binderGroup);
Search.addView(viewPage0);

return (UMWindow)Search;
}

	
	public void actionButton3_onclick(View control, UMEventArgs args) {
    String actionid = "button3_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button3_onclick()",UMActivity.getViewId(control),args);
}
public void actionButton0_onclick(View control, UMEventArgs args) {
    String actionid = "button0_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button0_onclick()",UMActivity.getViewId(control),args);
}
public void actionViewpage0_onload(View control, UMEventArgs args) {
    String actionid = "viewpage0_onload";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "loadEmotionDetail()",UMActivity.getViewId(control),args);
}


}
