package com.yonyou.heartwindow;

import com.yonyou.uap.um.application.ApplicationContext;
import com.yonyou.uap.um.base.*;
import com.yonyou.uap.um.common.*;
import com.yonyou.uap.um.third.*;
import com.yonyou.uap.um.control.*;
import com.yonyou.uap.um.core.*;
import com.yonyou.uap.um.binder.*;
import com.yonyou.uap.um.runtime.*;
import com.yonyou.uap.um.lexer.*;
import com.yonyou.uap.um.widget.*;
import com.yonyou.uap.um.widget.UmpSlidingLayout.SlidingViewType;
import com.yonyou.uap.um.log.ULog;
import java.util.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.webkit.*;
import android.content.*;
import android.graphics.*;
import android.widget.ImageView.ScaleType;

public abstract class MyActivity extends UMWindowActivity {

	protected UMWindow My = null;
protected XVerticalLayout viewPage0 = null;
protected XHorizontalLayout panel0 = null;
protected XHorizontalLayout panel1 = null;
protected UMButton button0 = null;
protected UMButton button1 = null;
protected XHorizontalLayout panel3 = null;
protected UMButton button2 = null;
protected UMLabel label0 = null;
protected UMWebView webcontrol0 = null;
protected XHorizontalLayout panel4 = null;
protected UMButton button3 = null;
protected UMLabel label1 = null;
protected UMLabel label2 = null;
protected XHorizontalLayout panel5 = null;
protected UMButton button4 = null;
protected UMButton button5 = null;
protected XHorizontalLayout panel6 = null;
protected XHorizontalLayout panel7 = null;
protected UMLabel label3 = null;
protected XHorizontalLayout panel8 = null;
protected UMWebView webcontrol1 = null;

	
	protected final static int ID_MY = 1815444649;
protected final static int ID_VIEWPAGE0 = 395468738;
protected final static int ID_PANEL0 = 1434730133;
protected final static int ID_PANEL1 = 574250341;
protected final static int ID_BUTTON0 = 608813255;
protected final static int ID_BUTTON1 = 688923626;
protected final static int ID_PANEL3 = 16117904;
protected final static int ID_BUTTON2 = 881487968;
protected final static int ID_LABEL0 = 1640629391;
protected final static int ID_WEBCONTROL0 = 1677864958;
protected final static int ID_PANEL4 = 970128144;
protected final static int ID_BUTTON3 = 1790688156;
protected final static int ID_LABEL1 = 1782698270;
protected final static int ID_LABEL2 = 2008675260;
protected final static int ID_PANEL5 = 881966719;
protected final static int ID_BUTTON4 = 1744201701;
protected final static int ID_BUTTON5 = 1113310907;
protected final static int ID_PANEL6 = 848232867;
protected final static int ID_PANEL7 = 340763099;
protected final static int ID_LABEL3 = 967586909;
protected final static int ID_PANEL8 = 1774149635;
protected final static int ID_WEBCONTROL1 = 1934192059;

	
	
	@Override
	public String getControllerName() {
		return "MyController";
	}
	
	@Override
	public String getContextName() {
		return "";
	}

	@Override
	public String getNameSpace() {
		return "com.yonyou.heartwindow";
	}

	protected void onCreate(Bundle savedInstanceState) {
		ULog.logLC("onCreate", this);
		super.onCreate(savedInstanceState);
        onInit(savedInstanceState);
        
	}
	
	@Override
	protected void onStart() {
		ULog.logLC("onStart", this);
		
		super.onStart();
	}

	@Override
	protected void onRestart() {
		ULog.logLC("onRestart", this);
		
		super.onRestart();
	}

	@Override
	protected void onResume() {
		ULog.logLC("onResume", this);
		
		super.onResume();
	}

	@Override
	protected void onPause() {
		ULog.logLC("onPause", this);
		
		super.onPause();
	}

	@Override
	protected void onStop() {
		ULog.logLC("onStop", this);
		
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		ULog.logLC("onDestroy", this);
		
		super.onDestroy();
	}
	
	public  void onInit(Bundle savedInstanceState) {
		ULog.logLC("onInit", this);
		UMActivity context = this;
		registerControl();
		this.getContainer();
		
		/*
		 new Thread() {
			 public void run() {
				 UMPDebugClient.startServer();
			 }
		 }.start();
		*/
		String sys_debug = ApplicationContext.getCurrent(this).getValue("sys_debug");
		if (sys_debug != null && sys_debug.equalsIgnoreCase("true")) {
			UMPDebugClient.waitForDebug();
		}

		IBinderGroup binderGroup = this;
		currentPage = getCurrentWindow(context, binderGroup);
super.setContentView(currentPage);

		
	}
	
	private void registerControl() {
		  idmap.put("My",ID_MY);
  idmap.put("viewPage0",ID_VIEWPAGE0);
  idmap.put("panel0",ID_PANEL0);
  idmap.put("panel1",ID_PANEL1);
  idmap.put("button0",ID_BUTTON0);
  idmap.put("button1",ID_BUTTON1);
  idmap.put("panel3",ID_PANEL3);
  idmap.put("button2",ID_BUTTON2);
  idmap.put("label0",ID_LABEL0);
  idmap.put("webcontrol0",ID_WEBCONTROL0);
  idmap.put("panel4",ID_PANEL4);
  idmap.put("button3",ID_BUTTON3);
  idmap.put("label1",ID_LABEL1);
  idmap.put("label2",ID_LABEL2);
  idmap.put("panel5",ID_PANEL5);
  idmap.put("button4",ID_BUTTON4);
  idmap.put("button5",ID_BUTTON5);
  idmap.put("panel6",ID_PANEL6);
  idmap.put("panel7",ID_PANEL7);
  idmap.put("label3",ID_LABEL3);
  idmap.put("panel8",ID_PANEL8);
  idmap.put("webcontrol1",ID_WEBCONTROL1);

	}
	
	public void onLoad() {
		ULog.logLC("onLoad", this);
		if(currentPage!=null) {
			currentPage.onLoad();
		}
	
		{ //viewPage0 - action:viewpage0_onload
    UMEventArgs args = new UMEventArgs(MyActivity.this);
    actionViewpage0_onload(viewPage0,args);

}

	}
	
	public void onDatabinding() {
		ULog.logLC("onDatabinding", this);
		super.onDatabinding();
		
	}
	
	@Override
	public void onReturn(String methodName, Object returnValue) {
		
	}

	@Override
	public void onAfterInit() {
		ULog.logLC("onAfterInit", this);
		
		onLoad();
	}
	
		@Override
	public Map<String,String> getPlugout(String id) {
		XJSON from = this.getUMContext();
		Map<String,String> r = super.getPlugout(id);
		
		return r;	
	}
	
	
	
	public View getPanel3View(final UMActivity context,IBinderGroup binderGroup) {
panel3 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL3
,"padding-right","8"
,"halign","RIGHT"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"background","#79c7c5"
,"width","0"
,"valign","center"
);
button2 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON2
,"halign","center"
,"height","30"
,"color","#e50011"
,"layout-type","hbox"
,"width","30"
,"font-size","17"
,"onclick","action:button2_onclick"
,"font-family","default"
,"font-pressed-color","#f2adb2"
,"valign","center"
,"background-image","search.png"
);
panel3.addView(button2);

return panel3;
}
public View getPanel0View(final UMActivity context,IBinderGroup binderGroup) {
panel0 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL0
,"halign","LEFT"
,"height","57"
,"layout-type","vbox"
,"background","#79c7c5"
,"width","fill"
,"valign","center"
);
panel1 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL1
,"halign","LEFT"
,"height","60.0"
,"weight","1"
,"layout-type","hbox"
,"background","#79c7c5"
,"width","0"
,"valign","center"
);
panel0.addView(panel1);
button0 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON0
,"halign","center"
,"width","100"
,"margin-bottom","0"
,"font-pressed-color","#f2adb2"
,"margin-right","20"
,"height","30"
,"color","#ffffff"
,"layout-type","hbox"
,"font-size","17"
,"background","#79c7c5"
,"value","全校统计"
,"onclick","action:button0_onclick"
,"font-family","default"
,"margin-top","0"
,"valign","center"
);
panel0.addView(button0);
button1 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON1
,"padding-left","0"
,"halign","center"
,"width","100"
,"font-pressed-color","#f2adb2"
,"height","30"
,"color","#79c7c5"
,"layout-type","hbox"
,"font-size","17"
,"value","我的学生"
,"margin-left","0"
,"font-family","default"
,"margin-top","0"
,"valign","center"
,"background-image","navbutton.png"
);
panel0.addView(button1);
View panel3 = (View) getPanel3View((UMActivity)context,binderGroup);
panel0.addView(panel3);

return panel0;
}
public View getPanel4View(final UMActivity context,IBinderGroup binderGroup) {
panel4 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL4
,"padding-left","16"
,"padding-right","16"
,"halign","LEFT"
,"height","24"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","center"
);
button3 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON3
,"halign","center"
,"height","fill"
,"color","#e50011"
,"layout-type","hbox"
,"width","24"
,"font-size","17"
,"font-family","default"
,"font-pressed-color","#f2adb2"
,"valign","center"
,"background-image","yujing.png"
);
panel4.addView(button3);
label1 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL1
,"halign","left"
,"widthwrap","94.0"
,"width","wrap"
,"content","低情绪预警人数:"
,"height","24"
,"color","#da797f"
,"background","#ffffff"
,"font-size","12"
,"layout-type","hbox"
,"onclick","action:label1_onclick"
,"font-family","default"
,"valign","center"
);
panel4.addView(label1);
label2 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL2
,"content","数据来源：新浪微博"
,"halign","center"
,"height","fill"
,"widthwrap","99.0"
,"color","#9b9b9b"
,"layout-type","hbox"
,"font-size","10"
,"width","wrap"
,"margin-left","70"
,"font-family","default"
,"valign","center"
);
panel4.addView(label2);

return panel4;
}
public View getPanel5View(final UMActivity context,IBinderGroup binderGroup) {
panel5 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL5
,"halign","CENTER"
,"height","52"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"margin-top","10"
,"valign","center"
);
button4 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON4
,"halign","center"
,"pressed-image","buttonhover.png"
,"width","100"
,"font-pressed-color","#ffffff"
,"height","33"
,"color","#79c7c5"
,"layout-type","hbox"
,"font-size","17"
,"value","学生列表"
,"onclick","action:button4_onclick"
,"font-family","default"
,"valign","center"
,"background-image","button.png"
);
panel5.addView(button4);
button5 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON5
,"halign","center"
,"pressed-image","buttonhover.png"
,"width","100"
,"font-pressed-color","#ffffff"
,"height","33"
,"color","#79c7c5"
,"layout-type","hbox"
,"font-size","17"
,"value","添加学生"
,"margin-left","40"
,"onclick","action:button5_onclick"
,"font-family","default"
,"valign","center"
,"background-image","button.png"
);
panel5.addView(button5);

return panel5;
}
public View getPanel7View(final UMActivity context,IBinderGroup binderGroup) {
panel7 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL7
,"halign","LEFT"
,"height","30"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"margin-top","10"
,"valign","center"
);
label3 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL3
,"halign","center"
,"widthwrap","72.0"
,"width","wrap"
,"content","情绪走势"
,"height","fill"
,"color","#9b9b9b"
,"background","#ffffff"
,"font-size","17"
,"layout-type","hbox"
,"margin-left","16"
,"font-family","default"
,"valign","center"
);
panel7.addView(label3);

return panel7;
}
public View getPanel8View(final UMActivity context,IBinderGroup binderGroup) {
panel8 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL8
,"halign","LEFT"
,"height","0"
,"weight","3"
,"layout-type","vbox"
,"width","fill"
,"valign","center"
);
webcontrol1 = (UMWebView)ThirdControl.createControl(new UMWebView(context),ID_WEBCONTROL1
,"halign","center"
,"startpage","examples/area-basic/myLine.html"
,"height","fill"
,"layout-type","hbox"
,"layout","vbox"
,"width","fill"
,"valign","TOP"
,"url","file:///android_asset/webcontrol/Highcharts/examples/area-basic/myLine.html"
);
panel8.addView(webcontrol1);

return panel8;
}
public View getViewPage0View(final UMActivity context,IBinderGroup binderGroup) {
viewPage0 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_VIEWPAGE0
,"halign","center"
,"height","fill"
,"onload","action:viewpage0_onload"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","TOP"
);
View panel0 = (View) getPanel0View((UMActivity)context,binderGroup);
viewPage0.addView(panel0);
label0 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL0
,"padding-left","16"
,"padding-right","16"
,"halign","left"
,"width","fill"
,"margin-bottom","10"
,"content","样本总数："
,"height","20"
,"color","#808080"
,"layout-type","vbox"
,"background","#ffffff"
,"font-size","12"
,"font-family","sans"
,"margin-top","15"
,"valign","center"
);
viewPage0.addView(label0);
webcontrol0 = (UMWebView)ThirdControl.createControl(new UMWebView(context),ID_WEBCONTROL0
,"halign","center"
,"startpage","examples/pie-basic/myPie.html"
,"height","0"
,"weight","4"
,"layout-type","vbox"
,"layout","vbox"
,"width","fill"
,"valign","TOP"
,"url","file:///android_asset/webcontrol/Highcharts/examples/pie-basic/myPie.html"
);
viewPage0.addView(webcontrol0);
View panel4 = (View) getPanel4View((UMActivity)context,binderGroup);
viewPage0.addView(panel4);
View panel5 = (View) getPanel5View((UMActivity)context,binderGroup);
viewPage0.addView(panel5);
panel6 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL6
,"halign","LEFT"
,"height","1"
,"layout-type","vbox"
,"background","#c0c0c0"
,"width","fill"
,"valign","center"
);
viewPage0.addView(panel6);
View panel7 = (View) getPanel7View((UMActivity)context,binderGroup);
viewPage0.addView(panel7);
View panel8 = (View) getPanel8View((UMActivity)context,binderGroup);
viewPage0.addView(panel8);

return viewPage0;
}
public UMWindow getCurrentWindow(final UMActivity context,IBinderGroup binderGroup) {
My = (UMWindow)ThirdControl.createControl(new UMWindow(context),ID_MY
,"halign","center"
,"height","800"
,"layout-type","linear"
,"layout","vbox"
,"width","fill"
,"controller","MyController"
,"valign","TOP"
,"namespace","com.yonyou.heartwindow"
);
View viewPage0 = (View) getViewPage0View((UMActivity)context,binderGroup);
My.addView(viewPage0);

return (UMWindow)My;
}

	
	public void actionButton5_onclick(View control, UMEventArgs args) {
    String actionid = "button5_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button5_onclick()",UMActivity.getViewId(control),args);
}
public void actionLabel1_onclick(View control, UMEventArgs args) {
    String actionid = "label1_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.label1_onclick()",UMActivity.getViewId(control),args);
}
public void actionButton0_onclick(View control, UMEventArgs args) {
    String actionid = "button0_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button0_onclick()",UMActivity.getViewId(control),args);
}
public void actionButton4_onclick(View control, UMEventArgs args) {
    String actionid = "button4_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button4_onclick()",UMActivity.getViewId(control),args);
}
public void actionButton2_onclick(View control, UMEventArgs args) {
    String actionid = "button2_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button2_onclick()",UMActivity.getViewId(control),args);
}
public void actionViewpage0_onload(View control, UMEventArgs args) {
    String actionid = "viewpage0_onload";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.viewPage0_onload()",UMActivity.getViewId(control),args);
}


}
