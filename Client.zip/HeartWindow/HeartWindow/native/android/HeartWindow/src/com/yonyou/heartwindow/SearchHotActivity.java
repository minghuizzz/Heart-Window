package com.yonyou.heartwindow;

import com.yonyou.uap.um.application.ApplicationContext;
import com.yonyou.uap.um.base.*;
import com.yonyou.uap.um.common.*;
import com.yonyou.uap.um.third.*;
import com.yonyou.uap.um.control.*;
import com.yonyou.uap.um.core.*;
import com.yonyou.uap.um.binder.*;
import com.yonyou.uap.um.runtime.*;
import com.yonyou.uap.um.lexer.*;
import com.yonyou.uap.um.widget.*;
import com.yonyou.uap.um.widget.UmpSlidingLayout.SlidingViewType;
import com.yonyou.uap.um.log.ULog;
import java.util.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.webkit.*;
import android.content.*;
import android.graphics.*;
import android.widget.ImageView.ScaleType;

public abstract class SearchHotActivity extends UMWindowActivity {

	protected UMWindow SearchHot = null;
protected XVerticalLayout viewPage0 = null;
protected XHorizontalLayout navigatorbar0 = null;
protected UMButton button0 = null;
protected XHorizontalLayout panel15 = null;
protected UMButton button1 = null;
protected UMTextbox textbox0 = null;
protected UMButton button2 = null;
protected UMLabel label0 = null;
protected XVerticalLayout panel0 = null;
protected XHorizontalLayout panel1 = null;
protected XHorizontalLayout panel4 = null;
protected XHorizontalLayout panel6 = null;
protected XVerticalLayout panel7 = null;
protected UMLabel label1 = null;
protected UMLabel label5 = null;
protected XHorizontalLayout panel5 = null;
protected XHorizontalLayout panel3 = null;
protected XVerticalLayout panel8 = null;
protected UMLabel label2 = null;
protected UMLabel label6 = null;
protected XHorizontalLayout panel2 = null;
protected XHorizontalLayout panel9 = null;
protected XHorizontalLayout panel11 = null;
protected XVerticalLayout panel12 = null;
protected UMLabel label3 = null;
protected UMLabel label7 = null;
protected XHorizontalLayout panel10 = null;
protected XHorizontalLayout panel13 = null;
protected XVerticalLayout panel14 = null;
protected UMLabel label4 = null;
protected UMLabel label8 = null;

	
	protected final static int ID_SEARCHHOT = 381875499;
protected final static int ID_VIEWPAGE0 = 836880995;
protected final static int ID_NAVIGATORBAR0 = 985183582;
protected final static int ID_BUTTON0 = 579736729;
protected final static int ID_PANEL15 = 1301912932;
protected final static int ID_BUTTON1 = 1990465525;
protected final static int ID_TEXTBOX0 = 1186320715;
protected final static int ID_BUTTON2 = 1892282754;
protected final static int ID_LABEL0 = 1874709633;
protected final static int ID_PANEL0 = 363664005;
protected final static int ID_PANEL1 = 1015787772;
protected final static int ID_PANEL4 = 1901514642;
protected final static int ID_PANEL6 = 526961950;
protected final static int ID_PANEL7 = 2069536317;
protected final static int ID_LABEL1 = 247474415;
protected final static int ID_LABEL5 = 562800020;
protected final static int ID_PANEL5 = 2012295966;
protected final static int ID_PANEL3 = 1187533535;
protected final static int ID_PANEL8 = 1314334396;
protected final static int ID_LABEL2 = 445942527;
protected final static int ID_LABEL6 = 702766045;
protected final static int ID_PANEL2 = 827610164;
protected final static int ID_PANEL9 = 914412278;
protected final static int ID_PANEL11 = 924551200;
protected final static int ID_PANEL12 = 1811866310;
protected final static int ID_LABEL3 = 2106206877;
protected final static int ID_LABEL7 = 708080016;
protected final static int ID_PANEL10 = 724235530;
protected final static int ID_PANEL13 = 677760377;
protected final static int ID_PANEL14 = 1512716636;
protected final static int ID_LABEL4 = 786379851;
protected final static int ID_LABEL8 = 1121726165;

	
	
	@Override
	public String getControllerName() {
		return "SearchHotController";
	}
	
	@Override
	public String getContextName() {
		return "";
	}

	@Override
	public String getNameSpace() {
		return "com.yonyou.heartwindow";
	}

	protected void onCreate(Bundle savedInstanceState) {
		ULog.logLC("onCreate", this);
		super.onCreate(savedInstanceState);
        onInit(savedInstanceState);
        
	}
	
	@Override
	protected void onStart() {
		ULog.logLC("onStart", this);
		
		super.onStart();
	}

	@Override
	protected void onRestart() {
		ULog.logLC("onRestart", this);
		
		super.onRestart();
	}

	@Override
	protected void onResume() {
		ULog.logLC("onResume", this);
		
		super.onResume();
	}

	@Override
	protected void onPause() {
		ULog.logLC("onPause", this);
		
		super.onPause();
	}

	@Override
	protected void onStop() {
		ULog.logLC("onStop", this);
		
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		ULog.logLC("onDestroy", this);
		
		super.onDestroy();
	}
	
	public  void onInit(Bundle savedInstanceState) {
		ULog.logLC("onInit", this);
		UMActivity context = this;
		registerControl();
		this.getContainer();
		
		/*
		 new Thread() {
			 public void run() {
				 UMPDebugClient.startServer();
			 }
		 }.start();
		*/
		String sys_debug = ApplicationContext.getCurrent(this).getValue("sys_debug");
		if (sys_debug != null && sys_debug.equalsIgnoreCase("true")) {
			UMPDebugClient.waitForDebug();
		}

		IBinderGroup binderGroup = this;
		currentPage = getCurrentWindow(context, binderGroup);
super.setContentView(currentPage);

		
	}
	
	private void registerControl() {
		  idmap.put("SearchHot",ID_SEARCHHOT);
  idmap.put("viewPage0",ID_VIEWPAGE0);
  idmap.put("navigatorbar0",ID_NAVIGATORBAR0);
  idmap.put("button0",ID_BUTTON0);
  idmap.put("panel15",ID_PANEL15);
  idmap.put("button1",ID_BUTTON1);
  idmap.put("textbox0",ID_TEXTBOX0);
  idmap.put("button2",ID_BUTTON2);
  idmap.put("label0",ID_LABEL0);
  idmap.put("panel0",ID_PANEL0);
  idmap.put("panel1",ID_PANEL1);
  idmap.put("panel4",ID_PANEL4);
  idmap.put("panel6",ID_PANEL6);
  idmap.put("panel7",ID_PANEL7);
  idmap.put("label1",ID_LABEL1);
  idmap.put("label5",ID_LABEL5);
  idmap.put("panel5",ID_PANEL5);
  idmap.put("panel3",ID_PANEL3);
  idmap.put("panel8",ID_PANEL8);
  idmap.put("label2",ID_LABEL2);
  idmap.put("label6",ID_LABEL6);
  idmap.put("panel2",ID_PANEL2);
  idmap.put("panel9",ID_PANEL9);
  idmap.put("panel11",ID_PANEL11);
  idmap.put("panel12",ID_PANEL12);
  idmap.put("label3",ID_LABEL3);
  idmap.put("label7",ID_LABEL7);
  idmap.put("panel10",ID_PANEL10);
  idmap.put("panel13",ID_PANEL13);
  idmap.put("panel14",ID_PANEL14);
  idmap.put("label4",ID_LABEL4);
  idmap.put("label8",ID_LABEL8);

	}
	
	public void onLoad() {
		ULog.logLC("onLoad", this);
		if(currentPage!=null) {
			currentPage.onLoad();
		}
	
		
	}
	
	public void onDatabinding() {
		ULog.logLC("onDatabinding", this);
		super.onDatabinding();
		
	}
	
	@Override
	public void onReturn(String methodName, Object returnValue) {
		
	}

	@Override
	public void onAfterInit() {
		ULog.logLC("onAfterInit", this);
		
		onLoad();
	}
	
		@Override
	public Map<String,String> getPlugout(String id) {
		XJSON from = this.getUMContext();
		Map<String,String> r = super.getPlugout(id);
		
		return r;	
	}
	
	
	
	public View getPanel15View(final UMActivity context,IBinderGroup binderGroup) {
panel15 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL15
,"halign","LEFT"
,"height","35"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"valign","center"
);
button1 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON1
,"halign","center"
,"height","fill"
,"color","#e50011"
,"layout-type","hbox"
,"width","42.0"
,"font-size","17"
,"onclick","action:button1_onclick"
,"font-family","default"
,"font-pressed-color","#f2adb2"
,"valign","center"
,"background-image","searchleft.png"
);
panel15.addView(button1);
textbox0 = (UMTextbox)ThirdControl.createControl(new UMTextbox(context),ID_TEXTBOX0
,"halign","LEFT"
,"height","fill"
,"weight","1"
,"maxlength","256"
,"color","#167ef8"
,"placeholder","快来搜搜"
,"layout-type","hbox"
,"font-size","14"
,"width","0"
,"font-family","default"
,"background-image","searchmid.png"
);
panel15.addView(textbox0);
button2 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON2
,"halign","center"
,"height","fill"
,"color","#e50011"
,"layout-type","hbox"
,"width","42.0"
,"font-size","17"
,"onclick","action:button2_onclick"
,"font-family","default"
,"font-pressed-color","#f2adb2"
,"valign","center"
,"background-image","searchright.png"
);
panel15.addView(button2);

return panel15;
}
public View getNavigatorbar0View(final UMActivity context,IBinderGroup binderGroup) {
navigatorbar0 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_NAVIGATORBAR0
,"padding-right","16"
,"padding-left","8"
,"halign","LEFT"
,"height","57"
,"color","#323232"
,"width","fill"
,"font-size","17"
,"background","#79c7c5"
,"layout-type","vbox"
,"font-family","default"
,"valign","center"
);
button0 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON0
,"halign","center"
,"pressed-image","backhover.png"
,"width","22"
,"font-pressed-color","#f2adb2"
,"margin-right","20"
,"height","22"
,"color","#e50011"
,"layout-type","hbox"
,"font-size","17"
,"onclick","action:button0_onclick"
,"font-family","default"
,"valign","center"
,"background-image","back.png"
);
navigatorbar0.addView(button0);
View panel15 = (View) getPanel15View((UMActivity)context,binderGroup);
navigatorbar0.addView(panel15);

return navigatorbar0;
}
public View getPanel7View(final UMActivity context,IBinderGroup binderGroup) {
panel7 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_PANEL7
,"padding-left","5"
,"halign","center"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"valign","TOP"
);
label1 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL1
,"halign","left"
,"weight","1"
,"width","fill"
,"margin-bottom","10"
,"font-weight","bold"
,"content","李开复"
,"height","0"
,"color","#000000"
,"font-size","14"
,"layout-type","vbox"
,"font-family","default"
,"valign","bottom"
);
panel7.addView(label1);
label5 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL5
,"content","创新工场董事长兼首席执行官"
,"halign","left"
,"height","0"
,"weight","1"
,"color","#7c7c7c"
,"layout-type","vbox"
,"font-size","14"
,"width","60"
,"font-family","default"
,"valign","top"
,"type","multiline"
);
panel7.addView(label5);

return panel7;
}
public View getPanel4View(final UMActivity context,IBinderGroup binderGroup) {
panel4 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL4
,"margin-right","5"
,"halign","LEFT"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"onclick","action:panel4_onclick"
,"valign","center"
);
panel6 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL6
,"halign","LEFT"
,"height","70"
,"border-radius","10"
,"layout-type","hbox"
,"width","70"
,"valign","center"
,"background-image","likaifu.jpg"
);
panel4.addView(panel6);
View panel7 = (View) getPanel7View((UMActivity)context,binderGroup);
panel4.addView(panel7);

return panel4;
}
public View getPanel8View(final UMActivity context,IBinderGroup binderGroup) {
panel8 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_PANEL8
,"padding-left","5"
,"halign","center"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"valign","TOP"
);
label2 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL2
,"content","马云"
,"halign","center"
,"height","60.0"
,"color","#000000"
,"layout-type","vbox"
,"font-size","14"
,"width","fill"
,"margin-bottom","10"
,"font-family","default"
,"font-weight","bold"
,"valign","bottom"
);
panel8.addView(label2);
label6 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL6
,"content","TNC(大自然保护协会)全球董事会董事马云"
,"halign","left"
,"height","0"
,"weight","1"
,"color","#7c7c7c"
,"layout-type","vbox"
,"font-size","14"
,"width","60"
,"font-family","default"
,"valign","top"
,"type","multiline"
);
panel8.addView(label6);

return panel8;
}
public View getPanel5View(final UMActivity context,IBinderGroup binderGroup) {
panel5 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL5
,"halign","LEFT"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"margin-left","5"
,"onclick","action:panel5_onclick"
,"valign","center"
);
panel3 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL3
,"halign","LEFT"
,"height","70"
,"border-radius","10"
,"layout-type","hbox"
,"width","70"
,"valign","center"
,"background-image","mayun.jpg"
);
panel5.addView(panel3);
View panel8 = (View) getPanel8View((UMActivity)context,binderGroup);
panel5.addView(panel8);

return panel5;
}
public View getPanel1View(final UMActivity context,IBinderGroup binderGroup) {
panel1 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL1
,"halign","CENTER"
,"height","0"
,"weight","1"
,"layout-type","vbox"
,"width","fill"
,"margin-bottom","10"
,"valign","top"
);
View panel4 = (View) getPanel4View((UMActivity)context,binderGroup);
panel1.addView(panel4);
View panel5 = (View) getPanel5View((UMActivity)context,binderGroup);
panel1.addView(panel5);

return panel1;
}
public View getPanel12View(final UMActivity context,IBinderGroup binderGroup) {
panel12 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_PANEL12
,"padding-left","5"
,"halign","center"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"valign","TOP"
);
label3 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL3
,"content","范冰冰"
,"halign","center"
,"height","65.0"
,"color","#000000"
,"layout-type","vbox"
,"font-size","14"
,"width","fill"
,"margin-bottom","10"
,"font-family","default"
,"font-weight","bold"
,"valign","bottom"
);
panel12.addView(label3);
label7 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL7
,"content","“爱里的心”公益项目发起人、演员范冰冰"
,"halign","left"
,"height","0"
,"weight","1"
,"color","#7c7c7c"
,"layout-type","vbox"
,"font-size","14"
,"width","60"
,"font-family","default"
,"valign","top"
,"type","multiline"
);
panel12.addView(label7);

return panel12;
}
public View getPanel9View(final UMActivity context,IBinderGroup binderGroup) {
panel9 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL9
,"margin-right","5"
,"halign","LEFT"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"onclick","action:panel9_onclick"
,"valign","center"
);
panel11 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL11
,"halign","LEFT"
,"height","70"
,"border-radius","10"
,"layout-type","hbox"
,"width","70"
,"valign","center"
,"background-image","fanbinbin.jpg"
);
panel9.addView(panel11);
View panel12 = (View) getPanel12View((UMActivity)context,binderGroup);
panel9.addView(panel12);

return panel9;
}
public View getPanel14View(final UMActivity context,IBinderGroup binderGroup) {
panel14 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_PANEL14
,"padding-left","5"
,"halign","center"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"valign","TOP"
);
label4 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL4
,"content","邓超"
,"halign","left"
,"height","65.0"
,"color","#000000"
,"layout-type","vbox"
,"font-size","14"
,"width","fill"
,"margin-bottom","10"
,"font-family","default"
,"font-weight","bold"
,"valign","bottom"
);
panel14.addView(label4);
label8 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL8
,"content","演员、导演邓超"
,"halign","left"
,"height","0"
,"weight","1"
,"color","#7c7c7c"
,"layout-type","vbox"
,"font-size","14"
,"width","60"
,"font-family","default"
,"valign","top"
,"type","multiline"
);
panel14.addView(label8);

return panel14;
}
public View getPanel10View(final UMActivity context,IBinderGroup binderGroup) {
panel10 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL10
,"halign","LEFT"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"width","0"
,"margin-left","5"
,"onclick","action:panel10_onclick"
,"valign","center"
);
panel13 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL13
,"halign","LEFT"
,"height","70"
,"border-radius","10"
,"layout-type","hbox"
,"width","70"
,"valign","center"
,"background-image","dengcaho.jpg"
);
panel10.addView(panel13);
View panel14 = (View) getPanel14View((UMActivity)context,binderGroup);
panel10.addView(panel14);

return panel10;
}
public View getPanel2View(final UMActivity context,IBinderGroup binderGroup) {
panel2 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL2
,"halign","CENTER"
,"height","0"
,"weight","1"
,"layout-type","vbox"
,"width","fill"
,"valign","top"
);
View panel9 = (View) getPanel9View((UMActivity)context,binderGroup);
panel2.addView(panel9);
View panel10 = (View) getPanel10View((UMActivity)context,binderGroup);
panel2.addView(panel10);

return panel2;
}
public View getPanel0View(final UMActivity context,IBinderGroup binderGroup) {
panel0 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_PANEL0
,"padding-right","16"
,"padding-left","16"
,"halign","center"
,"height","300"
,"layout-type","vbox"
,"width","fill"
,"valign","TOP"
);
View panel1 = (View) getPanel1View((UMActivity)context,binderGroup);
panel0.addView(panel1);
View panel2 = (View) getPanel2View((UMActivity)context,binderGroup);
panel0.addView(panel2);

return panel0;
}
public View getViewPage0View(final UMActivity context,IBinderGroup binderGroup) {
viewPage0 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_VIEWPAGE0
,"halign","center"
,"height","fill"
,"layout-type","vbox"
,"background","#F7F8F8"
,"width","fill"
,"valign","TOP"
);
View navigatorbar0 = (View) getNavigatorbar0View((UMActivity)context,binderGroup);
viewPage0.addView(navigatorbar0);
label0 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL0
,"halign","left"
,"width","fill"
,"content","热门搜索"
,"height","wrap"
,"color","#000000"
,"heightwrap","20.0"
,"font-size","14"
,"layout-type","vbox"
,"margin-left","16"
,"font-family","default"
,"margin-top","80"
,"valign","center"
);
viewPage0.addView(label0);
View panel0 = (View) getPanel0View((UMActivity)context,binderGroup);
viewPage0.addView(panel0);

return viewPage0;
}
public UMWindow getCurrentWindow(final UMActivity context,IBinderGroup binderGroup) {
SearchHot = (UMWindow)ThirdControl.createControl(new UMWindow(context),ID_SEARCHHOT
,"halign","center"
,"height","fill"
,"layout-type","linear"
,"layout","vbox"
,"width","fill"
,"controller","SearchHotController"
,"valign","TOP"
,"namespace","com.yonyou.heartwindow"
);
View viewPage0 = (View) getViewPage0View((UMActivity)context,binderGroup);
SearchHot.addView(viewPage0);

return (UMWindow)SearchHot;
}

	
	public void actionButton0_onclick(View control, UMEventArgs args) {
    String actionid = "button0_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button0_onclick()",UMActivity.getViewId(control),args);
}
public void actionButton2_onclick(View control, UMEventArgs args) {
    String actionid = "button2_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button2_onclick()",UMActivity.getViewId(control),args);
}
public void actionPanel9_onclick(View control, UMEventArgs args) {
    String actionid = "panel9_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "openEmotionDetail3()",UMActivity.getViewId(control),args);
}
public void actionButton1_onclick(View control, UMEventArgs args) {
    String actionid = "button1_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "search()",UMActivity.getViewId(control),args);
}
public void actionPanel4_onclick(View control, UMEventArgs args) {
    String actionid = "panel4_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "openEmotionDetail1()",UMActivity.getViewId(control),args);
}
public void actionPanel10_onclick(View control, UMEventArgs args) {
    String actionid = "panel10_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "openEmotionDetail4()",UMActivity.getViewId(control),args);
}
public void actionPanel5_onclick(View control, UMEventArgs args) {
    String actionid = "panel5_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "openEmotionDetail2()",UMActivity.getViewId(control),args);
}


}
