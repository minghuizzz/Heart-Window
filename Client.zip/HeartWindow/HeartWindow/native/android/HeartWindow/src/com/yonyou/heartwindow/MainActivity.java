package com.yonyou.heartwindow;

import com.yonyou.uap.um.application.ApplicationContext;
import com.yonyou.uap.um.base.*;
import com.yonyou.uap.um.common.*;
import com.yonyou.uap.um.third.*;
import com.yonyou.uap.um.control.*;
import com.yonyou.uap.um.core.*;
import com.yonyou.uap.um.binder.*;
import com.yonyou.uap.um.runtime.*;
import com.yonyou.uap.um.lexer.*;
import com.yonyou.uap.um.widget.*;
import com.yonyou.uap.um.widget.UmpSlidingLayout.SlidingViewType;
import com.yonyou.uap.um.log.ULog;
import java.util.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.webkit.*;
import android.content.*;
import android.graphics.*;
import android.widget.ImageView.ScaleType;

public abstract class MainActivity extends UMWindowActivity {

	protected UMWindow Main = null;
protected XVerticalLayout viewPage0 = null;
protected XHorizontalLayout panel0 = null;
protected XHorizontalLayout panel1 = null;
protected UMButton button0 = null;
protected UMButton button1 = null;
protected XHorizontalLayout panel3 = null;
protected UMButton button2 = null;
protected UMLabel label0 = null;
protected UMWebView webcontrol0 = null;
protected XHorizontalLayout panel4 = null;
protected UMButton button3 = null;
protected UMLabel label1 = null;
protected UMLabel label2 = null;
protected XHorizontalLayout panel5 = null;
protected XHorizontalLayout panel6 = null;
protected UMLabel label3 = null;
protected XHorizontalLayout panel7 = null;
protected UMWebView webcontrol1 = null;

	
	protected final static int ID_MAIN = 1732844785;
protected final static int ID_VIEWPAGE0 = 1092209070;
protected final static int ID_PANEL0 = 2137638021;
protected final static int ID_PANEL1 = 1638858875;
protected final static int ID_BUTTON0 = 1994631533;
protected final static int ID_BUTTON1 = 994973123;
protected final static int ID_PANEL3 = 924074189;
protected final static int ID_BUTTON2 = 771593231;
protected final static int ID_LABEL0 = 637088818;
protected final static int ID_WEBCONTROL0 = 1908307697;
protected final static int ID_PANEL4 = 792820281;
protected final static int ID_BUTTON3 = 1966084726;
protected final static int ID_LABEL1 = 222805170;
protected final static int ID_LABEL2 = 1961377148;
protected final static int ID_PANEL5 = 1392349396;
protected final static int ID_PANEL6 = 1150083485;
protected final static int ID_LABEL3 = 1685710901;
protected final static int ID_PANEL7 = 1532352062;
protected final static int ID_WEBCONTROL1 = 1378321156;

	
	
	@Override
	public String getControllerName() {
		return "MainController";
	}
	
	@Override
	public String getContextName() {
		return "";
	}

	@Override
	public String getNameSpace() {
		return "com.yonyou.heartwindow";
	}

	protected void onCreate(Bundle savedInstanceState) {
		ULog.logLC("onCreate", this);
		super.onCreate(savedInstanceState);
        onInit(savedInstanceState);
        
	}
	
	@Override
	protected void onStart() {
		ULog.logLC("onStart", this);
		
		super.onStart();
	}

	@Override
	protected void onRestart() {
		ULog.logLC("onRestart", this);
		
		super.onRestart();
	}

	@Override
	protected void onResume() {
		ULog.logLC("onResume", this);
		
		super.onResume();
	}

	@Override
	protected void onPause() {
		ULog.logLC("onPause", this);
		
		super.onPause();
	}

	@Override
	protected void onStop() {
		ULog.logLC("onStop", this);
		
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		ULog.logLC("onDestroy", this);
		
		super.onDestroy();
	}
	
	public  void onInit(Bundle savedInstanceState) {
		ULog.logLC("onInit", this);
		UMActivity context = this;
		registerControl();
		this.getContainer();
		
		/*
		 new Thread() {
			 public void run() {
				 UMPDebugClient.startServer();
			 }
		 }.start();
		*/
		String sys_debug = ApplicationContext.getCurrent(this).getValue("sys_debug");
		if (sys_debug != null && sys_debug.equalsIgnoreCase("true")) {
			UMPDebugClient.waitForDebug();
		}

		IBinderGroup binderGroup = this;
		currentPage = getCurrentWindow(context, binderGroup);
super.setContentView(currentPage);

		
	}
	
	private void registerControl() {
		  idmap.put("Main",ID_MAIN);
  idmap.put("viewPage0",ID_VIEWPAGE0);
  idmap.put("panel0",ID_PANEL0);
  idmap.put("panel1",ID_PANEL1);
  idmap.put("button0",ID_BUTTON0);
  idmap.put("button1",ID_BUTTON1);
  idmap.put("panel3",ID_PANEL3);
  idmap.put("button2",ID_BUTTON2);
  idmap.put("label0",ID_LABEL0);
  idmap.put("webcontrol0",ID_WEBCONTROL0);
  idmap.put("panel4",ID_PANEL4);
  idmap.put("button3",ID_BUTTON3);
  idmap.put("label1",ID_LABEL1);
  idmap.put("label2",ID_LABEL2);
  idmap.put("panel5",ID_PANEL5);
  idmap.put("panel6",ID_PANEL6);
  idmap.put("label3",ID_LABEL3);
  idmap.put("panel7",ID_PANEL7);
  idmap.put("webcontrol1",ID_WEBCONTROL1);

	}
	
	public void onLoad() {
		ULog.logLC("onLoad", this);
		if(currentPage!=null) {
			currentPage.onLoad();
		}
	
		{ //viewPage0 - action:viewpage0_onload
    UMEventArgs args = new UMEventArgs(MainActivity.this);
    actionViewpage0_onload(viewPage0,args);

}

	}
	
	public void onDatabinding() {
		ULog.logLC("onDatabinding", this);
		super.onDatabinding();
		
	}
	
	@Override
	public void onReturn(String methodName, Object returnValue) {
		
	}

	@Override
	public void onAfterInit() {
		ULog.logLC("onAfterInit", this);
		
		onLoad();
	}
	
		@Override
	public Map<String,String> getPlugout(String id) {
		XJSON from = this.getUMContext();
		Map<String,String> r = super.getPlugout(id);
		
		return r;	
	}
	
	
	
	public View getPanel3View(final UMActivity context,IBinderGroup binderGroup) {
panel3 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL3
,"padding-right","8"
,"halign","RIGHT"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"background","#79c7c5"
,"width","0"
,"valign","center"
);
button2 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON2
,"halign","center"
,"height","30"
,"color","#e50011"
,"layout-type","hbox"
,"width","30"
,"font-size","17"
,"onclick","action:button2_onclick"
,"font-family","default"
,"font-pressed-color","#f2adb2"
,"valign","center"
,"background-image","search.png"
);
panel3.addView(button2);

return panel3;
}
public View getPanel0View(final UMActivity context,IBinderGroup binderGroup) {
panel0 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL0
,"padding-top","14"
,"halign","LEFT"
,"height","57"
,"layout-type","vbox"
,"background","#79c7c5"
,"width","fill"
,"valign","center"
,"padding-bottom","13"
);
panel1 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL1
,"halign","LEFT"
,"height","fill"
,"weight","1"
,"layout-type","hbox"
,"background","#79c7c5"
,"width","0"
,"valign","center"
);
panel0.addView(panel1);
button0 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON0
,"halign","center"
,"width","100"
,"font-pressed-color","#79c7c5"
,"pressed-color","#79c7c5"
,"margin-right","20"
,"height","fill"
,"color","#79c7c5"
,"layout-type","hbox"
,"font-size","17"
,"value","全校统计"
,"font-family","default"
,"valign","center"
,"background-image","navbutton.png"
);
panel0.addView(button0);
button1 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON1
,"halign","center"
,"width","100"
,"font-pressed-color","#79c7c5"
,"margin-right","0"
,"height","fill"
,"color","#ffffff"
,"layout-type","hbox"
,"font-size","17"
,"value","我的学生"
,"margin-left","0"
,"onclick","action:button1_onclick"
,"font-family","default"
,"valign","center"
);
panel0.addView(button1);
View panel3 = (View) getPanel3View((UMActivity)context,binderGroup);
panel0.addView(panel3);

return panel0;
}
public View getPanel4View(final UMActivity context,IBinderGroup binderGroup) {
panel4 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL4
,"padding-left","16"
,"padding-right","16"
,"halign","LEFT"
,"height","24"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"margin-bottom","10"
,"valign","top"
);
button3 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON3
,"halign","center"
,"height","fill"
,"color","#e50011"
,"layout-type","hbox"
,"width","24"
,"font-size","17"
,"margin-left","0"
,"font-family","default"
,"font-pressed-color","#f2adb2"
,"valign","center"
,"background-image","yujing.png"
);
panel4.addView(button3);
label1 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL1
,"content","低情绪预警人数："
,"halign","left"
,"height","24"
,"widthwrap","104.0"
,"color","#da797f"
,"layout-type","hbox"
,"background","#ffffff"
,"font-size","12"
,"width","wrap"
,"font-family","default"
,"valign","center"
);
panel4.addView(label1);
label2 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL2
,"content","数据来源：新浪微博"
,"halign","center"
,"height","fill"
,"widthwrap","99.0"
,"color","#BDBDBD"
,"layout-type","hbox"
,"font-size","10"
,"width","wrap"
,"margin-left","55"
,"font-family","default"
,"valign","center"
);
panel4.addView(label2);

return panel4;
}
public View getPanel6View(final UMActivity context,IBinderGroup binderGroup) {
panel6 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL6
,"padding-left","16"
,"padding-right","16"
,"halign","LEFT"
,"height","30"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"margin-top","10"
,"valign","center"
);
label3 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL3
,"content","情绪走势"
,"halign","center"
,"height","fill"
,"widthwrap","84.0"
,"color","#9b9b9b"
,"layout-type","hbox"
,"font-size","20"
,"width","wrap"
,"font-family","default"
,"valign","center"
);
panel6.addView(label3);

return panel6;
}
public View getPanel7View(final UMActivity context,IBinderGroup binderGroup) {
panel7 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL7
,"halign","LEFT"
,"height","0"
,"weight","3"
,"layout-type","vbox"
,"width","fill"
,"valign","center"
);
webcontrol1 = (UMWebView)ThirdControl.createControl(new UMWebView(context),ID_WEBCONTROL1
,"halign","center"
,"startpage","examples/area-basic/index.htm"
,"height","fill"
,"layout-type","hbox"
,"layout","vbox"
,"width","fill"
,"valign","TOP"
,"url","file:///android_asset/webcontrol/Highcharts/examples/area-basic/index.htm"
);
panel7.addView(webcontrol1);

return panel7;
}
public View getViewPage0View(final UMActivity context,IBinderGroup binderGroup) {
viewPage0 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_VIEWPAGE0
,"halign","center"
,"height","fill"
,"onload","action:viewpage0_onload"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","TOP"
);
View panel0 = (View) getPanel0View((UMActivity)context,binderGroup);
viewPage0.addView(panel0);
label0 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL0
,"padding-left","16"
,"padding-right","16"
,"halign","left"
,"width","fill"
,"margin-bottom","10"
,"content","样本总数："
,"height","20"
,"color","#808080"
,"layout-type","vbox"
,"font-size","12"
,"background","#ffffff"
,"font-family","sans"
,"margin-top","15"
,"valign","center"
);
viewPage0.addView(label0);
webcontrol0 = (UMWebView)ThirdControl.createControl(new UMWebView(context),ID_WEBCONTROL0
,"halign","center"
,"startpage","examples/pie-basic/index.htm"
,"height","0"
,"weight","4"
,"layout-type","vbox"
,"layout","vbox"
,"width","fill"
,"valign","TOP"
,"url","file:///android_asset/webcontrol/Highcharts/examples/pie-basic/index.htm"
);
viewPage0.addView(webcontrol0);
View panel4 = (View) getPanel4View((UMActivity)context,binderGroup);
viewPage0.addView(panel4);
panel5 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL5
,"halign","LEFT"
,"height","1"
,"layout-type","vbox"
,"background","#CECED2"
,"width","fill"
,"valign","center"
);
viewPage0.addView(panel5);
View panel6 = (View) getPanel6View((UMActivity)context,binderGroup);
viewPage0.addView(panel6);
View panel7 = (View) getPanel7View((UMActivity)context,binderGroup);
viewPage0.addView(panel7);

return viewPage0;
}
public UMWindow getCurrentWindow(final UMActivity context,IBinderGroup binderGroup) {
Main = (UMWindow)ThirdControl.createControl(new UMWindow(context),ID_MAIN
,"halign","center"
,"height","800"
,"layout-type","linear"
,"layout","vbox"
,"width","fill"
,"controller","MainController"
,"valign","TOP"
,"namespace","com.yonyou.heartwindow"
);
View viewPage0 = (View) getViewPage0View((UMActivity)context,binderGroup);
Main.addView(viewPage0);

return (UMWindow)Main;
}

	
	public void actionButton2_onclick(View control, UMEventArgs args) {
    String actionid = "button2_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button2_onclick()",UMActivity.getViewId(control),args);
}
public void actionButton1_onclick(View control, UMEventArgs args) {
    String actionid = "button1_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button1_onclick()",UMActivity.getViewId(control),args);
}
public void actionViewpage0_onload(View control, UMEventArgs args) {
    String actionid = "viewpage0_onload";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.viewPage0_onload()",UMActivity.getViewId(control),args);
}


}
