package com.yonyou.heartwindow;

import com.yonyou.uap.um.application.ApplicationContext;
import com.yonyou.uap.um.base.*;
import com.yonyou.uap.um.common.*;
import com.yonyou.uap.um.third.*;
import com.yonyou.uap.um.control.*;
import com.yonyou.uap.um.core.*;
import com.yonyou.uap.um.binder.*;
import com.yonyou.uap.um.runtime.*;
import com.yonyou.uap.um.lexer.*;
import com.yonyou.uap.um.widget.*;
import com.yonyou.uap.um.widget.UmpSlidingLayout.SlidingViewType;
import com.yonyou.uap.um.log.ULog;
import java.util.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.webkit.*;
import android.content.*;
import android.graphics.*;
import android.widget.ImageView.ScaleType;

public abstract class MyCareActivity extends UMWindowActivity {

	protected UMWindow MyCare = null;
protected XVerticalLayout viewPage0 = null;
protected XHorizontalLayout panel0 = null;
protected UMButton button0 = null;
protected UMLabel label0 = null;
protected XHorizontalLayout panel1 = null;
protected UMListViewBase listviewdefine0 = null;
protected XHorizontalLayout panel3 = null;
protected UMLabel label3 = null;
protected UMLabel label4 = null;
protected UMLabel label5 = null;
protected UMButton button1 = null;

	
	protected final static int ID_MYCARE = 821362624;
protected final static int ID_VIEWPAGE0 = 427435112;
protected final static int ID_PANEL0 = 981654956;
protected final static int ID_BUTTON0 = 17434782;
protected final static int ID_LABEL0 = 2042905925;
protected final static int ID_PANEL1 = 1748613331;
protected final static int ID_LISTVIEWDEFINE0 = 703796966;
protected final static int ID_PANEL3 = 2061361998;
protected final static int ID_LABEL3 = 2087504765;
protected final static int ID_LABEL4 = 1688387884;
protected final static int ID_LABEL5 = 651430382;
protected final static int ID_BUTTON1 = 1394240792;

	
	
	@Override
	public String getControllerName() {
		return "MyCareController";
	}
	
	@Override
	public String getContextName() {
		return "";
	}

	@Override
	public String getNameSpace() {
		return "com.yonyou.heartwindow";
	}

	protected void onCreate(Bundle savedInstanceState) {
		ULog.logLC("onCreate", this);
		super.onCreate(savedInstanceState);
        onInit(savedInstanceState);
        
	}
	
	@Override
	protected void onStart() {
		ULog.logLC("onStart", this);
		
		super.onStart();
	}

	@Override
	protected void onRestart() {
		ULog.logLC("onRestart", this);
		
		super.onRestart();
	}

	@Override
	protected void onResume() {
		ULog.logLC("onResume", this);
		
		super.onResume();
	}

	@Override
	protected void onPause() {
		ULog.logLC("onPause", this);
		
		super.onPause();
	}

	@Override
	protected void onStop() {
		ULog.logLC("onStop", this);
		
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		ULog.logLC("onDestroy", this);
		
		super.onDestroy();
	}
	
	public  void onInit(Bundle savedInstanceState) {
		ULog.logLC("onInit", this);
		UMActivity context = this;
		registerControl();
		this.getContainer();
		
		/*
		 new Thread() {
			 public void run() {
				 UMPDebugClient.startServer();
			 }
		 }.start();
		*/
		String sys_debug = ApplicationContext.getCurrent(this).getValue("sys_debug");
		if (sys_debug != null && sys_debug.equalsIgnoreCase("true")) {
			UMPDebugClient.waitForDebug();
		}

		IBinderGroup binderGroup = this;
		currentPage = getCurrentWindow(context, binderGroup);
super.setContentView(currentPage);

		
	}
	
	private void registerControl() {
		  idmap.put("MyCare",ID_MYCARE);
  idmap.put("viewPage0",ID_VIEWPAGE0);
  idmap.put("panel0",ID_PANEL0);
  idmap.put("button0",ID_BUTTON0);
  idmap.put("label0",ID_LABEL0);
  idmap.put("panel1",ID_PANEL1);
  idmap.put("listviewdefine0",ID_LISTVIEWDEFINE0);
  idmap.put("panel3",ID_PANEL3);
  idmap.put("label3",ID_LABEL3);
  idmap.put("label4",ID_LABEL4);
  idmap.put("label5",ID_LABEL5);
  idmap.put("button1",ID_BUTTON1);

	}
	
	public void onLoad() {
		ULog.logLC("onLoad", this);
		if(currentPage!=null) {
			currentPage.onLoad();
		}
	
		{ //viewPage0 - action:viewpage0_onload
    UMEventArgs args = new UMEventArgs(MyCareActivity.this);
    actionViewpage0_onload(viewPage0,args);

}

	}
	
	public void onDatabinding() {
		ULog.logLC("onDatabinding", this);
		super.onDatabinding();
		
	}
	
	@Override
	public void onReturn(String methodName, Object returnValue) {
		
	}

	@Override
	public void onAfterInit() {
		ULog.logLC("onAfterInit", this);
		
		onLoad();
	}
	
		@Override
	public Map<String,String> getPlugout(String id) {
		XJSON from = this.getUMContext();
		Map<String,String> r = super.getPlugout(id);
		
		return r;	
	}
	
	
	
	public View getPanel0View(final UMActivity context,IBinderGroup binderGroup) {
panel0 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL0
,"halign","LEFT"
,"height","45"
,"layout-type","vbox"
,"background","#79c7c5"
,"width","fill"
,"valign","center"
);
button0 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON0
,"halign","center"
,"pressed-image","backhover.png"
,"width","25"
,"font-pressed-color","#f2adb2"
,"height","25"
,"color","#e50011"
,"layout-type","hbox"
,"font-size","17"
,"margin-left","8"
,"onclick","action:button0_onclick"
,"font-family","default"
,"valign","center"
,"background-image","back.png"
);
panel0.addView(button0);
label0 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL0
,"content","情绪低落学生列表"
,"halign","center"
,"height","fill"
,"weight","1"
,"color","#ffffff"
,"layout-type","hbox"
,"font-size","17"
,"width","0"
,"font-family","default"
,"valign","center"
);
panel0.addView(label0);
panel1 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL1
,"halign","LEFT"
,"height","30"
,"layout-type","hbox"
,"background","#79c7c5"
,"width","30"
,"valign","center"
);
panel0.addView(panel1);

return panel0;
}
public View getPanel3View(final UMActivity context,IBinderGroup binderGroup) {
panel3 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL3
,"border-bottom-width","1"
,"halign","LEFT"
,"height","60"
,"layout-type","vbox"
,"background","#FFFFFF"
,"width","fill"
,"onclick","action:panel3_onclick"
,"valign","center"
,"border-bottom-color","#C7C7C7"
);
label3 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL3
,"content","label"
,"bindfield","name"
,"halign","center"
,"height","fill"
,"weight","1"
,"color","#000000"
,"layout-type","hbox"
,"font-size","14"
,"width","0"
,"font-family","default"
,"valign","center"
);
panel3.addView(label3);
label4 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL4
,"content","label"
,"bindfield","uid"
,"halign","center"
,"height","fill"
,"color","#000000"
,"layout-type","hbox"
,"font-size","14"
,"width","0"
,"font-family","default"
,"valign","center"
);
panel3.addView(label4);
label5 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL5
,"content","label"
,"bindfield","context"
,"halign","center"
,"height","fill"
,"weight","3"
,"color","#000000"
,"layout-type","hbox"
,"font-size","14"
,"width","0"
,"font-family","default"
,"valign","center"
);
panel3.addView(label5);
button1 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON1
,"halign","center"
,"height","22"
,"color","#e50011"
,"pressed-image","nexthover.png"
,"layout-type","hbox"
,"width","22"
,"font-size","17"
,"font-family","default"
,"font-pressed-color","#f2adb2"
,"valign","center"
,"background-image","next.png"
);
panel3.addView(button1);

return panel3;
}
public View getListviewdefine0View(final UMActivity context,IBinderGroup binderGroup) {
listviewdefine0 = (UMListViewBase)ThirdControl.createControl(new UMListViewBase(context),ID_LISTVIEWDEFINE0
,"bindfield","list"
,"halign","center"
,"height","fill"
,"layout-type","vbox"
,"layout","vbox"
,"width","fill"
,"valign","TOP"
,"collapsed","true"
);
listviewdefine0.addListItemView("getPanel3View");

return listviewdefine0;
}
public View getViewPage0View(final UMActivity context,IBinderGroup binderGroup) {
viewPage0 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_VIEWPAGE0
,"halign","center"
,"height","fill"
,"onload","action:viewpage0_onload"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","TOP"
);
View panel0 = (View) getPanel0View((UMActivity)context,binderGroup);
viewPage0.addView(panel0);
View listviewdefine0 = (View) getListviewdefine0View((UMActivity)context,binderGroup);
viewPage0.addView(listviewdefine0);

return viewPage0;
}
public UMWindow getCurrentWindow(final UMActivity context,IBinderGroup binderGroup) {
MyCare = (UMWindow)ThirdControl.createControl(new UMWindow(context),ID_MYCARE
,"halign","center"
,"height","fill"
,"layout-type","linear"
,"layout","vbox"
,"width","fill"
,"controller","MyCareController"
,"valign","TOP"
,"namespace","com.yonyou.heartwindow"
);
View viewPage0 = (View) getViewPage0View((UMActivity)context,binderGroup);
MyCare.addView(viewPage0);

return (UMWindow)MyCare;
}

	
	public void actionButton0_onclick(View control, UMEventArgs args) {
    String actionid = "button0_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button0_onclick()",UMActivity.getViewId(control),args);
}
public void actionPanel3_onclick(View control, UMEventArgs args) {
    String actionid = "panel3_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "getWeb()",UMActivity.getViewId(control),args);
}
public void actionViewpage0_onload(View control, UMEventArgs args) {
    String actionid = "viewpage0_onload";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "getCare()",UMActivity.getViewId(control),args);
}


}
