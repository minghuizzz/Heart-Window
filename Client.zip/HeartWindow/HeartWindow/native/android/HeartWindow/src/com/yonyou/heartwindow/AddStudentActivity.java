package com.yonyou.heartwindow;

import com.yonyou.uap.um.application.ApplicationContext;
import com.yonyou.uap.um.base.*;
import com.yonyou.uap.um.common.*;
import com.yonyou.uap.um.third.*;
import com.yonyou.uap.um.control.*;
import com.yonyou.uap.um.core.*;
import com.yonyou.uap.um.binder.*;
import com.yonyou.uap.um.runtime.*;
import com.yonyou.uap.um.lexer.*;
import com.yonyou.uap.um.widget.*;
import com.yonyou.uap.um.widget.UmpSlidingLayout.SlidingViewType;
import com.yonyou.uap.um.log.ULog;
import java.util.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.webkit.*;
import android.content.*;
import android.graphics.*;
import android.widget.ImageView.ScaleType;

public abstract class AddStudentActivity extends UMWindowActivity {

	protected UMWindow AddStudent = null;
protected XVerticalLayout viewPage0 = null;
protected XHorizontalLayout panel0 = null;
protected UMButton button0 = null;
protected UMLabel label0 = null;
protected XHorizontalLayout panel1 = null;
protected UMTextbox textbox0 = null;
protected XHorizontalLayout panel2 = null;
protected UMTextbox textbox1 = null;
protected XHorizontalLayout panel3 = null;
protected UMButton button1 = null;

	
	protected final static int ID_ADDSTUDENT = 673541280;
protected final static int ID_VIEWPAGE0 = 309081526;
protected final static int ID_PANEL0 = 1137351888;
protected final static int ID_BUTTON0 = 2070490806;
protected final static int ID_LABEL0 = 143219944;
protected final static int ID_PANEL1 = 1977522770;
protected final static int ID_TEXTBOX0 = 1261171533;
protected final static int ID_PANEL2 = 680236469;
protected final static int ID_TEXTBOX1 = 1709390109;
protected final static int ID_PANEL3 = 271193504;
protected final static int ID_BUTTON1 = 1391239173;

	
	
	@Override
	public String getControllerName() {
		return "AddStudentController";
	}
	
	@Override
	public String getContextName() {
		return "";
	}

	@Override
	public String getNameSpace() {
		return "com.yonyou.heartwindow";
	}

	protected void onCreate(Bundle savedInstanceState) {
		ULog.logLC("onCreate", this);
		super.onCreate(savedInstanceState);
        onInit(savedInstanceState);
        
	}
	
	@Override
	protected void onStart() {
		ULog.logLC("onStart", this);
		
		super.onStart();
	}

	@Override
	protected void onRestart() {
		ULog.logLC("onRestart", this);
		
		super.onRestart();
	}

	@Override
	protected void onResume() {
		ULog.logLC("onResume", this);
		
		super.onResume();
	}

	@Override
	protected void onPause() {
		ULog.logLC("onPause", this);
		
		super.onPause();
	}

	@Override
	protected void onStop() {
		ULog.logLC("onStop", this);
		
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		ULog.logLC("onDestroy", this);
		
		super.onDestroy();
	}
	
	public  void onInit(Bundle savedInstanceState) {
		ULog.logLC("onInit", this);
		UMActivity context = this;
		registerControl();
		this.getContainer();
		
		/*
		 new Thread() {
			 public void run() {
				 UMPDebugClient.startServer();
			 }
		 }.start();
		*/
		String sys_debug = ApplicationContext.getCurrent(this).getValue("sys_debug");
		if (sys_debug != null && sys_debug.equalsIgnoreCase("true")) {
			UMPDebugClient.waitForDebug();
		}

		IBinderGroup binderGroup = this;
		currentPage = getCurrentWindow(context, binderGroup);
super.setContentView(currentPage);

		
	}
	
	private void registerControl() {
		  idmap.put("AddStudent",ID_ADDSTUDENT);
  idmap.put("viewPage0",ID_VIEWPAGE0);
  idmap.put("panel0",ID_PANEL0);
  idmap.put("button0",ID_BUTTON0);
  idmap.put("label0",ID_LABEL0);
  idmap.put("panel1",ID_PANEL1);
  idmap.put("textbox0",ID_TEXTBOX0);
  idmap.put("panel2",ID_PANEL2);
  idmap.put("textbox1",ID_TEXTBOX1);
  idmap.put("panel3",ID_PANEL3);
  idmap.put("button1",ID_BUTTON1);

	}
	
	public void onLoad() {
		ULog.logLC("onLoad", this);
		if(currentPage!=null) {
			currentPage.onLoad();
		}
	
		{ //viewPage0 - action:viewpage0_onload
    UMEventArgs args = new UMEventArgs(AddStudentActivity.this);
    actionViewpage0_onload(viewPage0,args);

}

	}
	
	public void onDatabinding() {
		ULog.logLC("onDatabinding", this);
		super.onDatabinding();
		
	}
	
	@Override
	public void onReturn(String methodName, Object returnValue) {
		
	}

	@Override
	public void onAfterInit() {
		ULog.logLC("onAfterInit", this);
		
		onLoad();
	}
	
		@Override
	public Map<String,String> getPlugout(String id) {
		XJSON from = this.getUMContext();
		Map<String,String> r = super.getPlugout(id);
		
		return r;	
	}
	
	
	
	public View getPanel0View(final UMActivity context,IBinderGroup binderGroup) {
panel0 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL0
,"padding-left","8"
,"halign","LEFT"
,"height","45"
,"layout-type","vbox"
,"background","#79c7c5"
,"width","fill"
,"valign","center"
);
button0 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON0
,"halign","center"
,"pressed-image","backhover.png"
,"width","22"
,"font-pressed-color","#f2adb2"
,"height","22"
,"color","#e50011"
,"font-size","17"
,"layout-type","hbox"
,"onclick","action:button0_onclick"
,"font-family","default"
,"valign","center"
,"background-image","back.png"
);
panel0.addView(button0);
label0 = (UMLabel)ThirdControl.createControl(new UMLabel(context),ID_LABEL0
,"content","添加学生"
,"halign","center"
,"height","20"
,"weight","1"
,"color","#ffffff"
,"layout-type","hbox"
,"font-size","17"
,"width","0"
,"font-family","default"
,"valign","center"
);
panel0.addView(label0);
panel1 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL1
,"halign","LEFT"
,"height","30"
,"layout-type","hbox"
,"background","#79c7c5"
,"width","30"
,"valign","center"
);
panel0.addView(panel1);

return panel0;
}
public View getViewPage0View(final UMActivity context,IBinderGroup binderGroup) {
viewPage0 = (XVerticalLayout)ThirdControl.createControl(new XVerticalLayout(context),ID_VIEWPAGE0
,"halign","center"
,"height","fill"
,"onload","action:viewpage0_onload"
,"layout-type","vbox"
,"background","#ffffff"
,"width","fill"
,"valign","TOP"
);
View panel0 = (View) getPanel0View((UMActivity)context,binderGroup);
viewPage0.addView(panel0);
textbox0 = (UMTextbox)ThirdControl.createControl(new UMTextbox(context),ID_TEXTBOX0
,"padding-left","4"
,"halign","LEFT"
,"placeholder","姓       名:"
,"width","200"
,"maxlength","256"
,"height","44"
,"color","#167ef8"
,"font-size","17"
,"background","#ffffff"
,"layout-type","vbox"
,"font-family","default"
,"margin-top","80"
);
viewPage0.addView(textbox0);
panel2 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL2
,"halign","LEFT"
,"height","1"
,"layout-type","vbox"
,"background","#CECED2"
,"width","200"
,"valign","center"
);
viewPage0.addView(panel2);
textbox1 = (UMTextbox)ThirdControl.createControl(new UMTextbox(context),ID_TEXTBOX1
,"padding-left","4"
,"halign","LEFT"
,"placeholder","微博账号："
,"width","200"
,"maxlength","256"
,"height","44"
,"color","#167ef8"
,"font-size","17"
,"background","#ffffff"
,"layout-type","vbox"
,"font-family","default"
,"margin-top","20"
);
viewPage0.addView(textbox1);
panel3 = (XHorizontalLayout)ThirdControl.createControl(new XHorizontalLayout(context),ID_PANEL3
,"halign","LEFT"
,"height","1"
,"layout-type","vbox"
,"background","#CECED2"
,"width","200"
,"valign","center"
);
viewPage0.addView(panel3);
button1 = (UMButton)ThirdControl.createControl(new UMButton(context),ID_BUTTON1
,"halign","center"
,"width","100"
,"font-pressed-color","#f2adb2"
,"height","33"
,"color","#79c7c5"
,"layout-type","vbox"
,"font-size","17"
,"value","录   入"
,"onclick","action:button1_onclick"
,"font-family","default"
,"margin-top","50"
,"valign","center"
,"background-image","button.png"
);
viewPage0.addView(button1);

return viewPage0;
}
public UMWindow getCurrentWindow(final UMActivity context,IBinderGroup binderGroup) {
AddStudent = (UMWindow)ThirdControl.createControl(new UMWindow(context),ID_ADDSTUDENT
,"halign","center"
,"height","fill"
,"layout-type","linear"
,"layout","vbox"
,"width","fill"
,"controller","AddStudentController"
,"valign","TOP"
,"namespace","com.yonyou.heartwindow"
);
View viewPage0 = (View) getViewPage0View((UMActivity)context,binderGroup);
AddStudent.addView(viewPage0);

return (UMWindow)AddStudent;
}

	
	public void actionButton0_onclick(View control, UMEventArgs args) {
    String actionid = "button0_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button0_onclick()",UMActivity.getViewId(control),args);
}
public void actionButton1_onclick(View control, UMEventArgs args) {
    String actionid = "button1_onclick";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "this.button1_onclick()",UMActivity.getViewId(control),args);
}
public void actionViewpage0_onload(View control, UMEventArgs args) {
    String actionid = "viewpage0_onload";
    args.put("language","javascript");
    args.put("containerName","");
  ActionProcessor.exec(this, actionid, args);
  this.getContainer().exec(actionid, "loadTag()",UMActivity.getViewId(control),args);
}


}
